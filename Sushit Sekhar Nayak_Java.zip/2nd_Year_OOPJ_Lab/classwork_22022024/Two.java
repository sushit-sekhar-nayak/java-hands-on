// Define an interface Motor with a data member –capacity and two methods such as run() and consume(). Define a Java class ‘Washing machine’ which implements this interface and write the code to check the value of the interface data member thru an object of the class.

import java.util.*;

interface Motor {
    int capacity = 100;
    void run ();
    void consume ();
}

class WashingMachine implements Motor {
    @Override
    public void run () {
        System.out.println ("Washing Machine is Running!");
    }
    public void consume () {
        System.out.println ("Washing Machine is consuming Power!");
    }
} 

public class Two {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        WashingMachine obj = new WashingMachine();
        System.out.println ("The Capacity of the Motor is : " + obj.capacity);
        obj.run();
        obj.consume();
    }
}