// Illustrate the usage of abstract class with following Java classes – An abstract class ‘student’ with two data members roll no, reg no, a method getinput() and an abstract method course(), A subclass ‘kiitian’ with course() method implementation. Write the driver class to print the all details of a kiitian object.

import java.util.*;

abstract class Student {
    int roll_no;
    int regn_no;
    void getinput () {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter Roll Number : ");
        roll_no = input.nextInt();
        System.out.print ("Enter Registration Number : ");
        regn_no = input.nextInt();
    }
    abstract void course ();
}

class KIITian extends Student {
    @Override
    void course () {
        System.out.println ("Course: Computer Science");
    }
}

public class One {
    public static void main (String args[]) {
        KIITian obj = new KIITian();
        obj.getinput();
        obj.course();
        System.out.println("Roll Number : " + obj.roll_no);
        System.out.println ("Registration Number : " + obj.regn_no);
    }
}