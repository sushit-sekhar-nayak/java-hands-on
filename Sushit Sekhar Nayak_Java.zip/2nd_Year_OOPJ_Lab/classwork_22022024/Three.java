// Define an interface with three methods – earnings(), deductions() and bonus() and define a Java class ‘Manager’ which uses this interface without implementing bonus() method. Also define another Java class ‘Substaff’ which extends from ‘Manager’ class and implements bonus() method.  Write the complete program to find out earnings, deduction and bonus of a sbstaff with basic salary amount entered by the user as per the following guidelines –
// earnings           basic + DA (80% of basic) + HRA (15% of basic)
// deduction PF       12% of basic
// bonus             50% of basic

import java.util.*;

interface Salary {
    void earnings(double basic);
    void deduction(double basic);
    void bonus(double basic);
}

class Manager implements Salary {
    @Override
    public void earnings(double basic) {
        double DA = 0.8 * basic;
        double HRA = 0.15 * basic;
        double totalEarnings = basic + DA + HRA;
        System.out.println("Earnings: " + totalEarnings);
    }

    @Override
    public void deduction(double basic) {
        double PF = 0.12 * basic;
        System.out.println("Deduction (PF): " + PF);
    }

    @Override
    public void bonus(double basic) {
        System.out.println("Bonus: Not applicable for Manager");
    }
}

class Substaff extends Manager {
    @Override
    public void bonus(double basic) {
        double bonus = 0.5 * basic;
        System.out.println("Bonus: " + bonus);
    }
}

public class Three {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter basic salary for Substaff: ");
        double basicSalary = input.nextDouble();

        Substaff substaff = new Substaff();
        substaff.earnings(basicSalary);
        substaff.deduction(basicSalary);
        substaff.bonus(basicSalary);
    }
}