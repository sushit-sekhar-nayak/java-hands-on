public class TypePromotion {
    void sum (int a, long b) {
        System.out.println(a+b);
    }
    void sum (double a, int b, int c) {
        System.out.println(a+b+c);
    }
    public static void main (String args[]) {
        TypePromotion obj = new TypePromotion();
        obj.sum(20,20);
        obj.sum(20,20,20);
    }
}