class Student {
    int rollno;
    String name;
    static String college = "KIIT";
    Student (int r,String n) {
        rollno = r;
        name = n;
    }
    void display () {
        System.out.println(rollno + " " + name + " " + college);
    }
}

public class StaticExample1 {
    public static void main (String args[]) {
        Student s1 = new Student (123, "Sushit");
        Student s2 = new Student (321, "Sekhar");
        s1.display ();
        s2.display ();
    }
}