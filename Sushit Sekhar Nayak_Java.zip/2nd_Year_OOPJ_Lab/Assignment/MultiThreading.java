public class MultiThreading {
    public static void main(String[] args) {
        Thread t1 = new Thread(new Process("Thread 1", 500));
        Thread t2 = new Thread(new Process("Thread 2", 1000));
        Thread t3 = new Thread(new Process("Thread 3", 1500));
        t1.start();
        t2.start();
        t3.start();
    }
    private static class Process implements Runnable {
        private String name;
        private int sleepTime;
        public Process (String name, int sleepTime) {
            this.name = name;
            this.sleepTime = sleepTime;
        }
        @Override
        public void run () {
            try {
                System.out.println("Started " + name);
                Thread.sleep(sleepTime);
                System.out.println("Finished " + name);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}w