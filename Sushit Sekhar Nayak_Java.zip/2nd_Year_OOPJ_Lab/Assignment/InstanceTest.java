public class Main {
    private static class Account {
        private int balance;

        public Account(int balance) {
            this.balance = balance;
        }

        public void deposit(int amount) {
            balance += amount;
        }

        public void withdraw(int amount) {
            balance -= amount;
        }

        public int getBalance() {
            return balance;
        }

        public void transfer(Account target, int amount) {
            synchronized (this) {
                System.out.println(Thread.currentThread().getName() + " locking " + this);
                synchronized (target) {
                    System.out.println(Thread.currentThread().getName() + " locking " + target);
                    if (this.balance >= amount) {
                        this.withdraw(amount);
                        target.deposit(amount);
                        System.out.println(Thread.currentThread().getName() + " Transfer succeeded");
                    } else {
                        System.out.println(Thread.currentThread().getName() + " Insufficient balance for transfer");
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        final Account account1 = new Account(100);
        final Account account2 = new Account(200);
        Thread thread1 = new Thread(() -> {
            account1.transfer(account2, 50);
        }, "Thread-1");
        Thread thread2 = new Thread(() -> {
            account2.transfer(account1, 30);
        }, "Thread-2");
        thread1.start();
        thread2.start();
    }
}