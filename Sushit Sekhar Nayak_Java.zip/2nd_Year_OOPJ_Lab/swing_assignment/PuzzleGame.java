import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PuzzleGame extends JFrame {
    private JButton[][] buttons;
    private int[][] puzzle;
    private int emptyRow, emptyCol;

    public PuzzleGame() {
        setTitle("Puzzle Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 300);
        setResizable(false);
        setLocationRelativeTo(null);

        // Initialize puzzle grid and buttons
        puzzle = new int[][]{{1, 2, 3}, {4, 5, 6}, {7, 8, 0}}; // 0 represents empty cell
        buttons = new JButton[3][3];

        // Create panel for puzzle grid
        JPanel puzzlePanel = new JPanel(new GridLayout(3, 3));
        puzzlePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create buttons and add them to the panel
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                JButton button = new JButton(String.valueOf(puzzle[row][col]));
                button.addActionListener(new ButtonClickListener(row, col));
                puzzlePanel.add(button);
                buttons[row][col] = button;
                if (puzzle[row][col] == 0) {
                    emptyRow = row;
                    emptyCol = col;
                }
            }
        }

        // Shuffle puzzle
        shuffle();

        // Add puzzle panel to frame
        add(puzzlePanel);
    }

    // Method to shuffle puzzle
    private void shuffle() {
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);
        int index = 0;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                puzzle[row][col] = numbers.get(index++);
                buttons[row][col].setText(String.valueOf(puzzle[row][col]));
                if (puzzle[row][col] == 0) {
                    emptyRow = row;
                    emptyCol = col;
                }
            }
        }
    }

    // Method to check if puzzle is solved
    private boolean isPuzzleSolved() {
        int count = 1;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (puzzle[row][col] != count % 9) {
                    return false;
                }
                count++;
            }
        }
        return true;
    }

    // Action listener for puzzle buttons
    private class ButtonClickListener implements ActionListener {
        private int row, col;

        public ButtonClickListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if ((row == emptyRow && Math.abs(col - emptyCol) == 1) ||
                    (col == emptyCol && Math.abs(row - emptyRow) == 1)) {
                buttons[emptyRow][emptyCol].setText(buttons[row][col].getText());
                buttons[row][col].setText("");
                puzzle[emptyRow][emptyCol] = puzzle[row][col];
                puzzle[row][col] = 0;
                emptyRow = row;
                emptyCol = col;
                if (isPuzzleSolved()) {
                    JOptionPane.showMessageDialog(PuzzleGame.this, "Congratulations! Puzzle Solved!");
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PuzzleGame puzzleGame = new PuzzleGame();
            puzzleGame.setVisible(true);
        });
    }
}
