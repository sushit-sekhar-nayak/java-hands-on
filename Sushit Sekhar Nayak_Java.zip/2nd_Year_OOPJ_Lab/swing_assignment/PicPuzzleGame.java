import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PicPuzzleGame extends JFrame {

    private BufferedImage image;
    private JPanel puzzlePanel;
    private List<ImageTile> tiles = new ArrayList<>();

    private class ImageTile extends JButton {
        private BufferedImage tileImage;
        private int index;

        public ImageTile(BufferedImage image, int index) {
            this.tileImage = image;
            this.index = index;
            setIcon(new ImageIcon(tileImage));
            setPreferredSize(new Dimension(image.getWidth(), image.getHeight()));
            addActionListener(e -> moveTile());
        }

        private void moveTile() {
            int emptyIndex = tiles.size() - 1; // Last tile is the empty space
            int emptyRow = emptyIndex / 3;
            int emptyCol = emptyIndex % 3;
            int clickedRow = index / 3;
            int clickedCol = index % 3;

            // Check if the clicked tile is adjacent to the empty space
            if ((Math.abs(emptyRow - clickedRow) == 1 && emptyCol == clickedCol) ||
                    (Math.abs(emptyCol - clickedCol) == 1 && emptyRow == clickedRow)) {
                Collections.swap(tiles, index, emptyIndex);
                updatePuzzlePanel();
            }
        }
    }

    public PicPuzzleGame(File imageFile) {
        try {
            image = ImageIO.read(imageFile);
            initUI();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading image: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void initUI() {
        setTitle("Pic Puzzle Game");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        puzzlePanel = new JPanel(new GridLayout(3, 3));
        createTiles();
        add(puzzlePanel, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void createTiles() {
        int tileWidth = image.getWidth() / 3;
        int tileHeight = image.getHeight() / 3;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int x = j * tileWidth;
                int y = i * tileHeight;
                BufferedImage tileImage = image.getSubimage(x, y, tileWidth, tileHeight);
                if (i == 2 && j == 2) { // Empty space
                    tiles.add(null);
                    continue;
                }
                ImageTile tile = new ImageTile(tileImage, i * 3 + j);
                tiles.add(tile);
                puzzlePanel.add(tile);
            }
        }
        shufflePuzzle();
    }

    private void shufflePuzzle() {
        Collections.shuffle(tiles.subList(0, tiles.size() - 1)); // Exclude last (empty) tile
        updatePuzzlePanel();
    }

    private void updatePuzzlePanel() {
        puzzlePanel.removeAll();
        for (ImageTile tile : tiles) {
            if (tile != null) {
                puzzlePanel.add(tile);
            }
        }
        puzzlePanel.revalidate();
        puzzlePanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                new PicPuzzleGame(selectedFile);
            }
        });
    }
}
