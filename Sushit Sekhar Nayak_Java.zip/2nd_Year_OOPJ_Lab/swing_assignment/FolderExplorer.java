import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class FolderExplorer extends JFrame {
    private JTree directoryTree;

    public FolderExplorer() {
        setTitle("Folder Explorer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Create root node
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");

        // Create directory tree
        directoryTree = new JTree(root);
        directoryTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        directoryTree.setShowsRootHandles(true);
        directoryTree.setRootVisible(false);

        // Create renderer to display folder icon for directories
        DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) directoryTree.getCellRenderer();
        ImageIcon folderIcon = new ImageIcon("folder_icon.png"); // Provide the path to your folder icon
        renderer.setClosedIcon(folderIcon);
        renderer.setOpenIcon(folderIcon);

        // Create scroll pane and add tree to panel
        JScrollPane scrollPane = new JScrollPane(directoryTree);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create button to select directory
        JButton selectButton = new JButton("Select Directory");
        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedDirectory = fileChooser.getSelectedFile();
                    displayDirectory(selectedDirectory);
                }
            }
        });
        panel.add(selectButton, BorderLayout.SOUTH);

        add(panel);
    }

    // Method to display directory in tree
    private void displayDirectory(File directory) {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(directory.getName());
        populateNode(root, directory);
        directoryTree.setModel(new DefaultTreeModel(root));
    }

    // Recursively populate tree node with files and subdirectories
    private void populateNode(DefaultMutableTreeNode node, File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(f.getName());
                node.add(childNode);
                populateNode(childNode, f);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FolderExplorer explorer = new FolderExplorer();
            explorer.setVisible(true);
        });
    }
}