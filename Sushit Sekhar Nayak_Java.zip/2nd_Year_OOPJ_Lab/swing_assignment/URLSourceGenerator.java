import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class URLSourceGenerator extends JFrame {

    private JTextField urlField;
    private JTextArea sourceArea;
    private JButton fetchButton;

    public URLSourceGenerator() {
        setTitle("URL Source Generator");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create components
        urlField = new JTextField(30);
        sourceArea = new JTextArea(20, 50);
        sourceArea.setEditable(false);
        fetchButton = new JButton("Fetch Source");

        // Set layout
        setLayout(new BorderLayout());

        // Create panel for URL input and fetch button
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Enter URL: "));
        inputPanel.add(urlField);
        inputPanel.add(fetchButton);

        // Add components to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(sourceArea), BorderLayout.CENTER);

        // Add action listener to fetch button
        fetchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fetchURLSource();
            }
        });
    }

    private void fetchURLSource() {
        String urlString = urlField.getText();
        StringBuilder sourceBuilder = new StringBuilder();

        try {
            URL url = new URL(urlString);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                sourceBuilder.append(line).append("\n");
            }

            reader.close();
        } catch (IOException ex) {
            sourceBuilder.append("Error fetching URL source: ").append(ex.getMessage());
        }

        sourceArea.setText(sourceBuilder.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            URLSourceGenerator generator = new URLSourceGenerator();
            generator.setVisible(true);
        });
    }
}
