import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OnlineExam extends JFrame {

    private JLabel questionLabel;
    private JRadioButton[] options;
    private ButtonGroup optionGroup;
    private JButton nextButton;
    private int currentQuestionIndex;
    private int score;

    private String[] questions = {
            "What is the capital of France?",
            "What is the largest mammal?",
            "What is 2 + 2?"
    };

    private String[][] optionsData = {
            {"Paris", "London", "Berlin", "Rome"},
            {"Elephant", "Blue Whale", "Giraffe", "Lion"},
            {"3", "4", "5", "6"}
    };

    private int[] answers = {0, 1, 1}; // Index of correct options for each question

    public OnlineExam() {
        setTitle("Online Exam");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel questionPanel = new JPanel();
        questionLabel = new JLabel();
        questionPanel.add(questionLabel);
        add(questionPanel, BorderLayout.NORTH);

        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(4, 1));
        options = new JRadioButton[4];
        optionGroup = new ButtonGroup();
        for (int i = 0; i < options.length; i++) {
            options[i] = new JRadioButton();
            optionsPanel.add(options[i]);
            optionGroup.add(options[i]);
        }
        add(optionsPanel, BorderLayout.CENTER);

        nextButton = new JButton("Next");
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processNext();
            }
        });
        add(nextButton, BorderLayout.SOUTH);

        showQuestion(0);
    }

    private void showQuestion(int index) {
        currentQuestionIndex = index;
        questionLabel.setText(questions[index]);
        for (int i = 0; i < options.length; i++) {
            options[i].setText(optionsData[index][i]);
            options[i].setSelected(false);
        }
    }

    private void processNext() {
        for (int i = 0; i < options.length; i++) {
            if (options[i].isSelected() && i == answers[currentQuestionIndex]) {
                score++;
                break;
            }
        }
        if (currentQuestionIndex < questions.length - 1) {
            showQuestion(currentQuestionIndex + 1);
        } else {
            JOptionPane.showMessageDialog(this, "Exam completed! Your score: " + score);
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new OnlineExam().setVisible(true);
            }
        });
    }
}