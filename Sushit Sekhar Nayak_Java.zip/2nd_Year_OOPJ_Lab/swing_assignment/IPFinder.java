import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class IPFinder extends JFrame implements ActionListener {
    private JTextField domainField;
    private JButton findButton;
    private JLabel resultLabel;

    public IPFinder() {
        setTitle("IP Finder");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 1));

        domainField = new JTextField();
        findButton = new JButton("Find IP");
        resultLabel = new JLabel("");

        findButton.addActionListener(this);

        panel.add(new JLabel("Enter Domain Name:"));
        panel.add(domainField);
        panel.add(findButton);
        panel.add(resultLabel);

        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == findButton) {
            String domain = domainField.getText().trim();
            if (!domain.isEmpty()) {
                try {
                    String ip = java.net.InetAddress.getByName(domain).getHostAddress();
                    resultLabel.setText("IP Address: " + ip);
                } catch (Exception ex) {
                    resultLabel.setText("Error: " + ex.getMessage());
                }
            } else {
                resultLabel.setText("Please enter a domain name.");
            }
        }
    }

    public static void main(String[] args) {
        new IPFinder();
    }
}
