public class Qsn_4 {

    static int minElement (int arr[]) {
        int start = 0;
        int end = arr.length-1;
        int mid = start + ((end-start)/2);
        while (arr[mid] > arr[end]) {
            mid++;
        }
        return arr[mid];
        while (start <= end) {
            if (arr[mid] > arr[arr.length-1]) {
                start = mid + 1;
            }
            else if (arr[mid] < )
        }
    }

    public static void main(String[] args) {
        int arr[] = {5, 6, 7, 8, 9, 10, 1, 2, 3, 4};
        System.out.print("The Minimum Element is : " + minElement (arr));
    }
}