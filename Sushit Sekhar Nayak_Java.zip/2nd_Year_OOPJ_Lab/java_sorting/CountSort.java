public class CountSort {

    static void countSort (int[] arr) {
        int max = arr[0];
        for (int i=0; i<arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        int count[] = new int[max+1];
        for (int i=0; i<arr.length; i++) {
            count[arr[i]]++;
        }
        // convert Count array into Prefix-Sum Array
        int sum=0;
        for (int i=0; i<count.length; i++) {
            sum += count[i];
            count[i] = sum;
        }
        int[] ans = new int[arr.length];
        for (int i=arr.length-1; i>=0; i--) {
            ans[count[arr[i]]-1] = arr[i];
            count[arr[i]]--;
        }
        for (int i=0; i<arr.length; i++) {
            arr[i] = ans[i];
        }
    }

    public static void main(String[] args) {
        int arr[] = {4, 3, 1, 5, 3, 1, 3, 5};
        countSort (arr);
        System.out.print("The Array after Sorting is : ");
        for (int i=0; i<arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}