public class BucketSort {

    static void bucketSort (int[] arr) {
        
    }

    public static void main(String[] args) {
        int[] arr = {7, 19, 25, 14, 5, 20, 11, 23, 1};
        bucketSort (arr);
        System.out.print("The Array after Sorting is : ");
        for (int i=0; i<arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}