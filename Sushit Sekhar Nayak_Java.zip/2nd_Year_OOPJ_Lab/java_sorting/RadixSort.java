public class RadixSort {

    // Modified Count Sort Algorithm
    static void countSort (int[] arr, int place) {
        int count[] = new int[10];
        for (int i=0; i<arr.length; i++) {
            count[arr[i]/place%10]++;
        }
        // Convert Count array into Prefix-Sum Array
        int sum=0;
        for (int i=0; i<count.length; i++) {
            sum += count[i];
            count[i] = sum;
        }
        int[] ans = new int[arr.length];
        for (int i=arr.length-1; i>=0; i--) {
            ans[count[arr[i]/place%10]-1] = arr[i];
            count[arr[i]/place%10]--;
        }
        for (int i=0; i<arr.length; i++) {
            arr[i] = ans[i];
        }
    }

    static void radixSort (int[] arr) {
        int max = arr[0];
        for (int i=0; i<arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        for (int place=1; max/place>0; place*=10) {
            countSort(arr, place);
        }
    }

    public static void main(String[] args) {
        int[] arr = {170, 45, 75, 90, 802, 2};
        radixSort (arr);
        System.out.print("The Array after Sorting is : ");
        for (int i=0; i<arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}