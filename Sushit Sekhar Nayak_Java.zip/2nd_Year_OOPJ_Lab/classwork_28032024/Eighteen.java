import javax.swing.*;
import java.awt.*;

public class Eighteen extends JFrame {
    public Eighteen() {
        setTitle("Student Detail Form");

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel headLabel = new JLabel("Student Details Form");
        headLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Set font style here
        JLabel idLabel = new JLabel("Student Id:");
        JTextField idField = new JTextField(20);
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(20);
        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField(20);
        JLabel phoneLabel = new JLabel("Phone No:");
        JTextField phoneField = new JTextField(20);

        JButton b1 = new JButton("Add Student");
        JButton b2 = new JButton("Cancel");

        // Add headLabel with specified font and centered alignment
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Span two columns
        gbc.anchor = GridBagConstraints.CENTER; // Center alignment
        add(headLabel, gbc);
        gbc.gridwidth = 1; // Reset gridwidth to default
        gbc.anchor = GridBagConstraints.NORTHWEST; // Reset anchor

        // Add other components with GridBagConstraints to specify their positions
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(idLabel, gbc);
        gbc.gridx = 1;
        add(idField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(nameLabel, gbc);
        gbc.gridx = 1;
        add(nameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(addressLabel, gbc);
        gbc.gridx = 1;
        add(addressField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        add(phoneLabel, gbc);
        gbc.gridx = 1;
        add(phoneField, gbc);

        // Create new GridBagConstraints for buttons
        GridBagConstraints buttonConstraints = new GridBagConstraints();
        buttonConstraints.anchor = GridBagConstraints.EAST; // Right alignment
        buttonConstraints.insets = new Insets(10, 5, 5, 5); // Adjust insets for spacing
        buttonConstraints.gridwidth = GridBagConstraints.REMAINDER; // Stretch to end of row

        // Add buttons with adjusted GridBagConstraints
        buttonConstraints.gridy = 5; // Place buttons in the same row as text fields
        add(b1, buttonConstraints);
        add(b2, buttonConstraints);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);

        setSize(500, 300); // Increased height to accommodate buttons
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Eighteen frame = new Eighteen();
            frame.setVisible(true);
        });
    }
}