import javax.swing.*;
import java.awt.*;

public class ThirtyThree extends JFrame {
    private JPanel panel;
    private JTable table;

    public ThirtyThree() {
        setTitle("Timetable Example");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel headingLabel = new JLabel("Time Table", SwingConstants.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD + Font.ITALIC, 24)); // Set font style, size, and type
        panel.add(headingLabel, BorderLayout.NORTH);

        String[] columnNames = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};

        // Sample data for demonstration
        String[][] data = new String[10][5];
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 5; j++) {
                data[i][j] = ""; // Initially, all cells are empty
            }
        }

        table = new JTable(data, columnNames);
        table.setPreferredScrollableViewportSize(new Dimension(500, 300));
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new ThirtyThree();
    }
}
