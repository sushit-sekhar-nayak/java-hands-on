// Create a another Window with the following features:
// a. Window size is 400x200
// b. The command for the default close operation
// button is shutting down the JVM.
// c. The title of the window is <Border Layout Window=.
// d. There two labels in the north and south areas.
// e. Set the text on a label, horizontal alignment is
// <CENTER=.

import java.awt.*;
import javax.swing.*;

public class Three extends JFrame {
    private JLabel label1, label2;

    public Three () {
        super ("My First Frame");

        label1 = new JLabel("This is the North Border", SwingConstants.CENTER);
        add(label1, BorderLayout.NORTH);

        label2 = new JLabel("This is the South Border", SwingConstants.CENTER);
        add(label2, BorderLayout.SOUTH);

        setSize(400, 200);
        setVisible(true);
    }
    public static void main (String args[]) {
        Three app = new Three();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}