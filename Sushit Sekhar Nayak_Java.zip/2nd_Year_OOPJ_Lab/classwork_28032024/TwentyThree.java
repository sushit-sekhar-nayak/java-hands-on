import javax.swing.*;
import java.awt.*;

public class TwentyThree extends JFrame {

    private JLabel nameLabel, addressLabel, genderLabel, titleLabel;
    private JTextField nameField, addressField;
    private JButton saveButton, cancelButton;
    private JRadioButton maleRadioButton, femaleRadioButton;
    private ButtonGroup genderButtonGroup;

    public TwentyThree() {
        setTitle("Student Detail Form");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        titleLabel = new JLabel("Student Details", SwingConstants.CENTER);

        nameLabel = new JLabel("Name:");
        addressLabel = new JLabel("Address:");
        genderLabel = new JLabel("Gender:");

        nameField = new JTextField(10);
        addressField = new JTextField(10);

        maleRadioButton = new JRadioButton("Male");
        femaleRadioButton = new JRadioButton("Female");
        genderButtonGroup = new ButtonGroup();
        genderButtonGroup.add(maleRadioButton);
        genderButtonGroup.add(femaleRadioButton);

        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(6, 2, 4, 4));
        mainPanel.add(titleLabel);
        mainPanel.add(new JLabel());
        mainPanel.add(nameLabel);
        mainPanel.add(nameField);
        mainPanel.add(addressLabel);
        mainPanel.add(addressField);
        mainPanel.add(genderLabel);
        mainPanel.add(createGenderSelectionPanel());
        mainPanel.add(new JLabel());
        mainPanel.add(buttonPanel);
        add(mainPanel);
        setVisible(true);
    }

    private JPanel createGenderSelectionPanel() {
        JPanel genderPanel = new JPanel();
        genderPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        return genderPanel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TwentyThree());
    }
}