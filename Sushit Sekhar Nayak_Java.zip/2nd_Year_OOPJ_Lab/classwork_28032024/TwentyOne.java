import javax.swing.*;
import java.awt.*;

public class TwentyOne extends JFrame {

    private JLabel idLabel,nameLabel, addressLabel, phoneLabel,titleLabel;
    private JTextField idField,nameField, addressField,phoneField;
    private JButton addButton, cancelButton;

    public TwentyOne() {
        setTitle("Student Detail Form");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        titleLabel = new JLabel("Student Details Form", SwingConstants.CENTER);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // Align titleLabel at the center

        idLabel = new JLabel("Student Id");
        nameLabel = new JLabel("Name:");
        addressLabel = new JLabel("Address:");
        phoneLabel = new JLabel("Phone Number:");

        idField = new JTextField(10);
        nameField = new JTextField(10);
        addressField = new JTextField(10);
        phoneField = new JTextField(10);

        addButton = new JButton("Add Student");
        cancelButton = new JButton("Cancel");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(cancelButton);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(6, 2, 4, 4));
        mainPanel.add(titleLabel); // Add titleLabel to mainPanel
        mainPanel.add(new JLabel());
        mainPanel.add(idLabel);
        mainPanel.add(idField);
        mainPanel.add(nameLabel);
        mainPanel.add(nameField);
        mainPanel.add(addressLabel);
        mainPanel.add(addressField);
        mainPanel.add(phoneLabel);
        mainPanel.add(phoneField);
        mainPanel.add(new JLabel());
        mainPanel.add(buttonPanel);
        add(mainPanel);
        setVisible(true);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TwentyOne());
    }
}
