import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ThirtyFour extends JFrame {
    private JComboBox<String> nameComboBox;
    private JTextField addressField;
    private JButton itemButton; // Changed from JComboBox to JButton
    private JTextField priceField; // Changed from JButton to JTextField
    private JSpinner quantitySpinner;
    private JButton orderButton;
    private JButton addCustomerButton;

    public ThirtyFour() {
        setTitle("Customer Order Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 220); // Adjusted window size
        setLayout(new GridLayout(6, 2, 10, 5)); // Adjusted gap between rows and columns

        // Customer Name combo box
        JLabel customerNameLabel = new JLabel("Customer Name:");
        nameComboBox = new JComboBox<>();
        nameComboBox.addItem("John");
        nameComboBox.addItem("Alice");
        nameComboBox.addItem("Bob");
        nameComboBox.addItem("Emily");
        JPanel customerNamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Adjusted panel layout
        customerNamePanel.add(customerNameLabel);
        customerNamePanel.add(nameComboBox);
        add(customerNamePanel);

        // Add Customer button
        addCustomerButton = new JButton("Add Customer");
        addCustomerButton.addActionListener(new AddCustomerButtonListener());
        add(addCustomerButton);
        add(new JLabel()); // Placeholder for alignment

        // Address field
        JLabel addressLabel = new JLabel("Address:");
        addressField = new JTextField();
        add(addressLabel);
        add(addressField);
        add(new JLabel()); // Placeholder for alignment

        // Product button and Price components
        JLabel productLabel = new JLabel("Product:");
        itemButton = new JButton("Select Product"); // Changed to JButton
        itemButton.addActionListener(new ProductButtonListener());
        JPanel productPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Nested panel for product and price
        productPanel.add(productLabel);
        productPanel.add(itemButton);
        add(productPanel);

        JLabel priceLabel = new JLabel("Price:");
        priceField = new JTextField();
        priceField.setEditable(false); // Ensure the field is not editable
        add(priceLabel);
        add(priceField);
        add(new JLabel()); // Placeholder for alignment

        // Quantity spinner
        JLabel quantityLabel = new JLabel("Quantity:");
        SpinnerModel spinnerModel = new SpinnerNumberModel(1, 1, 100, 1);
        quantitySpinner = new JSpinner(spinnerModel);
        add(quantityLabel);
        add(quantitySpinner);
        add(new JLabel()); // Placeholder for alignment

        // Order button
        add(new JLabel()); // Placeholder for alignment
        orderButton = new JButton("Place Order");
        orderButton.addActionListener(new OrderButtonListener());
        add(orderButton);
        add(new JLabel()); // Placeholder for alignment

        setVisible(true);
    }

    // Action listener for add customer button
    class AddCustomerButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String newName = JOptionPane.showInputDialog(ThirtyFour.this, "Enter new customer name:");
            if (newName != null && !newName.isEmpty()) {
                nameComboBox.addItem(newName);
                nameComboBox.setSelectedItem(newName);
            }
        }
    }

    // Action listener for product button
    class ProductButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // Implement product selection logic here (placeholder)
            String selectedProduct = JOptionPane.showInputDialog(ThirtyFour.this, "Select a product:");
            if (selectedProduct != null && !selectedProduct.isEmpty()) {
                itemButton.setText(selectedProduct);
            }
        }
    }

    // Action listener for order button
    class OrderButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String name = (String) nameComboBox.getSelectedItem();
            String address = addressField.getText();
            String product = itemButton.getText(); // Get text from product button
            int quantity = (int) quantitySpinner.getValue();

            // Process order (This is a placeholder. You should implement the actual order processing logic)
            System.out.println("Order placed by: " + name);
            System.out.println("Address: " + address);
            System.out.println("Product: " + product);
            System.out.println("Quantity: " + quantity);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ThirtyFour::new);
    }
}