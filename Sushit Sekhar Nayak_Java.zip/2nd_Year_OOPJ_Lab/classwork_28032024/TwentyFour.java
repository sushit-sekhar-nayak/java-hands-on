import javax.swing.*;
import java.awt.*;

public class TwentyFour extends JFrame {
    public TwentyFour() {
        // Set the title of the window
        setTitle("RadioButton Test");
        
        // Set layout manager
        setLayout(new FlowLayout());

        // Create radio buttons
        JRadioButton plainButton = new JRadioButton("Plain", true);
        JRadioButton boldButton = new JRadioButton("Bold");
        JRadioButton italicButton = new JRadioButton("Italic");
        JRadioButton boldItalicButton = new JRadioButton("Bold/Italic");

        // Group the radio buttons
        ButtonGroup group = new ButtonGroup();
        group.add(plainButton);
        group.add(boldButton);
        group.add(italicButton);
        group.add(boldItalicButton);

        // Add radio buttons to the frame
        add(plainButton);
        add(boldButton);
        add(italicButton);
        add(boldItalicButton);

        // Set default close operation and window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 100);
        setLocationRelativeTo(null); // Center the window
    }

    public static void main(String[] args) {
        // Run the program on the event-dispatching thread for thread safety
        SwingUtilities.invokeLater(() -> {
            // Create an instance of the RadioButtonTest24 class
            TwentyFour frame = new TwentyFour();
            // Make the window visible
            frame.setVisible(true);
        });
    }
}