import javax.swing.*;
import java.awt.*;

public class TwentyEight extends JFrame {
    public TwentyEight() {
        setTitle("RadioButton Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Create a panel for radio buttons
        JPanel radioPanel = new JPanel();
        radioPanel.setLayout(new BoxLayout(radioPanel, BoxLayout.Y_AXIS));

        // Create radio buttons
        JRadioButton birdButton = new JRadioButton("Bird");
        JRadioButton catButton = new JRadioButton("Cat");
        JRadioButton dogButton = new JRadioButton("Dog");
        JRadioButton rabbitButton = new JRadioButton("Rabbit");
        JRadioButton pigButton = new JRadioButton("Pig");

        // Add radio buttons to button group
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(birdButton);
        buttonGroup.add(catButton);
        buttonGroup.add(dogButton);
        buttonGroup.add(rabbitButton);
        buttonGroup.add(pigButton);

        // Add radio buttons to radio panel
        radioPanel.add(birdButton);
        radioPanel.add(catButton);
        radioPanel.add(dogButton);
        radioPanel.add(rabbitButton);
        radioPanel.add(pigButton);

        // Create a panel for the image
        JPanel imagePanel = new JPanel();
        ImageIcon pigImage = new ImageIcon("animals.jpeg"); // Replace "pig.jpg" with the path to your pig image file
        JLabel pigLabel = new JLabel(pigImage);
        imagePanel.add(pigLabel);

        // Create a panel to hold both radio buttons and image
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(radioPanel, BorderLayout.WEST);
        mainPanel.add(imagePanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TwentyEight window = new TwentyEight();
            window.setVisible(true);
        });
    }
}