import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class TwentyNine extends JFrame {
    public TwentyNine() {
        setTitle("DataBase Application Example");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 200);
        setLocationRelativeTo(null);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create menus
        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");
        JMenu helpMenu = new JMenu("Help");

        // Add menus to menu bar
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);

        // Set the menu bar to the frame
        setJMenuBar(menuBar);

        // Create toolbar
        JToolBar toolBar = new JToolBar();

        // Load icons for the toolbar buttons and resize them
        ImageIcon icon1 = resizeIcon(new ImageIcon("icon1.png"), 32, 32);
        ImageIcon icon2 = resizeIcon(new ImageIcon("icon2.jpeg"), 32, 32);
        ImageIcon icon3 = resizeIcon(new ImageIcon("icon3.jpeg"), 32, 32);
        ImageIcon icon4 = resizeIcon(new ImageIcon("icon4.png"), 32, 32);
        ImageIcon icon5 = resizeIcon(new ImageIcon("icon5.png"), 32, 32);
        ImageIcon icon6 = resizeIcon(new ImageIcon("icon6.png"), 32, 32);

        // Create toolbar buttons with resized icons
        JButton button1 = new JButton(icon1);
        JButton button2 = new JButton(icon2);
        JButton button3 = new JButton(icon3);
        JButton button4 = new JButton(icon4);
        JButton button5 = new JButton(icon5);
        JButton button6 = new JButton(icon6);

        // Add toolbar buttons to the toolbar
        toolBar.add(button1);
        toolBar.add(button2);
        toolBar.add(button3);
        toolBar.add(button4);
        toolBar.add(button5);
        toolBar.add(button6);

        // Add the toolbar to the frame
        add(toolBar, BorderLayout.NORTH);
    }

    // Method to resize ImageIcon
    private ImageIcon resizeIcon(ImageIcon icon, int width, int height) {
        Image img = icon.getImage();
        Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(resizedImg);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TwentyNine window = new TwentyNine();
            window.setVisible(true);
        });
    }
}