// Enhance the window created at exercise1 with the
// following features:
// a. Title of the window is <Border Layout Window=
// b. There are five JButtons as follows. (the default
// layout of the JFrame is BorderLayout)

import java.awt.*;
import javax.swing.*;

public class Two extends JFrame {
    private JButton east, west, north, south, center;

    public Two () {
        super ("Border Layout Window");

        east = new JButton("East");
        add(east, BorderLayout.EAST);
        west = new JButton("West");
        add(west, BorderLayout.WEST);
        north = new JButton("North");
        add(north, BorderLayout.NORTH);
        south = new JButton("South");
        add(south, BorderLayout.SOUTH);
        center = new JButton("Center");
        add(center, BorderLayout.CENTER);

        setSize(300, 300);
        setVisible(true);
    }
    public static void main (String args[]) {
        Two app = new Two();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}