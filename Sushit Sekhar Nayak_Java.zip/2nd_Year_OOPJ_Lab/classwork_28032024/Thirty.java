import javax.swing.*;
import java.awt.*;

public class Thirty extends JFrame {
    private JTextArea textArea;
    private JMenuBar menuBar;
    private JMenu fileMenu, editMenu, viewMenu, helpMenu, formatMenu;
    private JMenuItem newMenuItem, openMenuItem, saveMenuItem, saveAsMenuItem, exitMenuItem;
    private JMenuItem cutMenuItem, copyMenuItem, pasteMenuItem, selectAllMenuItem;
    private JMenuItem viewMenuItem1, viewMenuItem2, viewMenuItem3;
    private JMenuItem helpMenuItem1, helpMenuItem2, helpMenuItem3;
    private JMenuItem formatMenuItem1, formatMenuItem2, formatMenuItem3;

    public Thirty() {
        setTitle("Notepad");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        menuBar = new JMenuBar();

        fileMenu = new JMenu("File");
        newMenuItem = new JMenuItem("New");
        openMenuItem = new JMenuItem("Open");
        saveMenuItem = new JMenuItem("Save");
        saveAsMenuItem = new JMenuItem("Save As");
        exitMenuItem = new JMenuItem("Exit");
        fileMenu.add(newMenuItem);
        fileMenu.add(openMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(saveMenuItem);
        fileMenu.add(saveAsMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(exitMenuItem);

        editMenu = new JMenu("Edit");
        cutMenuItem = new JMenuItem("Cut");
        copyMenuItem = new JMenuItem("Copy");
        pasteMenuItem = new JMenuItem("Paste");
        selectAllMenuItem = new JMenuItem("Select All");
        editMenu.add(cutMenuItem);
        editMenu.add(copyMenuItem);
        editMenu.add(pasteMenuItem);
        editMenu.addSeparator();
        editMenu.add(selectAllMenuItem);

        formatMenu = new JMenu("Format");
        formatMenuItem1 = new JMenuItem("Text Size");
        formatMenuItem2 = new JMenuItem("Page Layout");
        formatMenuItem3 = new JMenuItem("Border");
        formatMenu.add(formatMenuItem1);
        formatMenu.add(formatMenuItem2);
        formatMenu.add(formatMenuItem3);

        viewMenu = new JMenu("View");
        viewMenuItem1 = new JMenuItem("Archived");
        viewMenuItem2 = new JMenuItem("Saved");
        viewMenuItem3 = new JMenuItem("Trash");
        viewMenu.add(viewMenuItem1);
        viewMenu.add(viewMenuItem2);
        viewMenu.add(viewMenuItem3);

        helpMenu = new JMenu("Help");
        helpMenuItem1 = new JMenuItem("Questions");
        helpMenuItem2 = new JMenuItem("Contacts");
        helpMenuItem3 = new JMenuItem("Social Media");
        helpMenu.add(helpMenuItem1);
        helpMenu.add(helpMenuItem2);
        helpMenu.add(helpMenuItem3);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(formatMenu);
        menuBar.add(viewMenu);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Thirty::new);
    }
}