import javax.swing.*;
import java.awt.*;

public class TwentyFive extends JFrame {
    public TwentyFive() {
        // Set the title of the window
        setTitle("ComboBox Demo");

        // Set layout manager to BorderLayout for better control over positioning
        setLayout(new BorderLayout(10, 10));

        // Create italicized heading label and place it at the top, centered
        JLabel headingLabel = new JLabel("ComboBox Demo", SwingConstants.CENTER);
        headingLabel.setFont(new Font(headingLabel.getFont().getName(), Font.ITALIC, headingLabel.getFont().getSize()));
        add(headingLabel, BorderLayout.NORTH);

        // Create a panel for the combo boxes with FlowLayout
        JPanel comboBoxPanel = new JPanel(new FlowLayout());

        // Create labels for combo boxes
        JLabel dateLabel = new JLabel("Date:");
        JLabel monthLabel = new JLabel("Month:");
        JLabel dayLabel = new JLabel("Day:");

        // Create combo boxes with sample data
        String[] years = {"2013", "2014", "2015", "2016"};
        String[] months = {"January", "February", "March", "April"};
        String[] days = {"1", "2", "3", "4", "5", "6"};

        JComboBox<String> dateComboBox = new JComboBox<>(years);
        JComboBox<String> monthComboBox = new JComboBox<>(months);
        JComboBox<String> dayComboBox = new JComboBox<>(days);

        // Set selected items
        dateComboBox.setSelectedItem("2013");
        monthComboBox.setSelectedItem("April");
        dayComboBox.setSelectedItem("6");

        // Add components to the combo box panel
        comboBoxPanel.add(dateLabel);
        comboBoxPanel.add(dateComboBox);
        comboBoxPanel.add(monthLabel);
        comboBoxPanel.add(monthComboBox);
        comboBoxPanel.add(dayLabel);
        comboBoxPanel.add(dayComboBox);

        // Add the combo box panel to the center of the main layout
        add(comboBoxPanel, BorderLayout.CENTER);

        // Set default close operation and window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 150);
        setLocationRelativeTo(null); // Center the window
    }

    public static void main(String[] args) {
        // Run the program on the event-dispatching thread for thread safety
        SwingUtilities.invokeLater(() -> {
            // Create an instance of the ComboBoxDemo25 class
            TwentyFive frame = new TwentyFive();
            // Make the window visible
            frame.setVisible(true);
        });
    }
}