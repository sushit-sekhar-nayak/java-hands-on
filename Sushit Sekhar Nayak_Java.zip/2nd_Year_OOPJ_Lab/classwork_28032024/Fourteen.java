import javax.swing.*;
import java.awt.*;

public class Fourteen extends JFrame {

    public Fourteen() {
        setTitle("Demonstrate TextField");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField textField = new JTextField("Niroth...", 10);
        textField.setEditable(false);
        textField.setHorizontalAlignment(SwingConstants.RIGHT);
        textField.setFont(new Font("Arial", Font.BOLD, 20));

        add(textField, BorderLayout.NORTH);

        setSize (350, 300);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Fourteen frame = new Fourteen();
            frame.setVisible(true);
        });
    }
}