import javax.swing.*;
import java.awt.*;

public class Twenty extends JFrame {
    public Twenty() {
        setTitle("Student Detail Form");

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel idLabel = new JLabel("Student Id:");
        JTextField idField = new JTextField(20);
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(20);
        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField(20);
        JLabel phoneLabel = new JLabel("Phone No:");
        JTextField phoneField = new JTextField(20);

        // Add components with GridBagConstraints to specify their positions
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(idLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(idField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(nameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(nameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(addressLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(addressField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(phoneLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(phoneField, gbc);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);

        setSize(500, 300);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Twenty frame = new Twenty();
            frame.setVisible(true);
        });
    }
}
