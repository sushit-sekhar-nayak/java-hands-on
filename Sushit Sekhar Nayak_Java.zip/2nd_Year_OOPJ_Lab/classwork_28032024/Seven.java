import java.awt.*;
import java.awt.*;

import javax.swing.*;

public class Seven extends JFrame {
    private JButton b1, b2, b3, b4;

    public Seven () {
        super ("Flow Layout Window");

        FlowLayout layout = new FlowLayout();

        Container container = getContentPane();
        container.setLayout(layout);

        b1 = new JButton("Button 1");
        container.add (b1);
        b2 = new JButton("This is a button");
        container.add (b2);
        b3 = new JButton("Button 2");
        container.add (b3);
        b4 = new JButton("Execute Button");
        container.add (b4);

        layout.setAlignment(FlowLayout.RIGHT);
        layout.layoutContainer(container);

        setSize(350, 200);
        setVisible(true);;
    }

    public static void main(String[] args) {
        Seven app = new Seven();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}