import javax.swing.*;
import java.awt.*;

public class TwentySix extends JFrame {

    public TwentySix() {
        setTitle("Equalizer");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        JLabel titleLabel = new JLabel("Equalizer", SwingConstants.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        JPanel sliderPanel = new JPanel(new GridLayout(1, 10));

        int[] startingPositions = {50, 60, 40, 60, 30, 60, 70, 90, 40, 20};

        for (int i = 0; i < 10; i++) {
            JSlider slider = new JSlider(JSlider.VERTICAL, 0, 100, startingPositions[i]);
            sliderPanel.add(slider);
        }
        add(sliderPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TwentySix::new);
    }
}