import javax.swing.*;
import java.awt.*;

public class TwentySeven extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, closeButton, helpButton;
    private JCheckBox rememberCheckbox;
    private JComboBox<String> databaseComboBox;
    private JLabel encryptionLabel;

    public TwentySeven() {
        setTitle("Login");
        setSize(500, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel usernamePanel = createPanelWithLabelAndComponent("Username:", usernameField = new JTextField(15));

        // Create a panel for the login button with right-aligned FlowLayout
        JPanel loginButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        loginButton = new JButton("OK");
        loginButtonPanel.add(loginButton);
        usernamePanel.add(loginButtonPanel);

        JPanel passwordPanel = createPanelWithLabelAndComponent("Password:", passwordField = new JPasswordField(15));

        // Create a panel for the close button with right-aligned FlowLayout
        JPanel closeButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        closeButton = new JButton("Close");
        closeButtonPanel.add(closeButton);
        passwordPanel.add(closeButtonPanel);

        JPanel databasePanel = createPanelWithLabelAndComponent("Database:", databaseComboBox = new JComboBox<>(new String[]{"Common", "DB2", "DB3"}));

        // Create a panel for the help button with right-aligned FlowLayout
        JPanel helpButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        helpButton = new JButton("Help");
        helpButtonPanel.add(helpButton);
        databasePanel.add(helpButtonPanel);

        rememberCheckbox = new JCheckBox("Remember password");

        encryptionLabel = new JLabel("Encryption status: unencrypted");

        JPanel checkboxPanel = new JPanel();
        checkboxPanel.add(rememberCheckbox);

        JPanel mainPanel = new JPanel(new GridLayout(0, 1));
        mainPanel.add(usernamePanel);
        mainPanel.add(passwordPanel);
        mainPanel.add(databasePanel);
        mainPanel.add(checkboxPanel);
        mainPanel.add(encryptionLabel);

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createPanelWithLabelAndComponent(String labelText, JComponent component) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel label = new JLabel(labelText);
        panel.add(label);
        panel.add(component);
        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TwentySeven::new);
    }
}