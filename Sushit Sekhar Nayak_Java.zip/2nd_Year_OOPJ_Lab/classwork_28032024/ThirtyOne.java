import javax.swing.*;
import java.awt.*;

public class ThirtyOne extends JFrame {
    public ThirtyOne() {
        // Set the title of the window
        setTitle("Slider Example");

        // Create a slider with the specified range and initial value
        JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 50, 25);
        slider.setMajorTickSpacing(10);
        slider.setMinorTickSpacing(1);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);

        // Add the slider to the frame
        add(slider);

        // Set default close operation and window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 100);
        setLocationRelativeTo(null); // Center the window
    }

    public static void main(String[] args) {
        // Run the program on the event-dispatching thread for thread safety
        SwingUtilities.invokeLater(() -> {
            // Create an instance of the SliderExample31 class
            ThirtyOne frame = new ThirtyOne();
            // Make the window visible
            frame.setVisible(true);
        });
    }
}