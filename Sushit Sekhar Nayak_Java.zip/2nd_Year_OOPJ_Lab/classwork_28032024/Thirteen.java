import java.awt.*;
import javax.swing.*;

public class Thirteen extends JFrame {
    private JTextField textField;
    private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16;

    public Thirteen () {

        super ("Calculator");

        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(5, 4, 5, 5));

        textField = new JTextField();
        container.add (textField, BorderLayout.NORTH);

        b1 = new JButton("7");
        panel.add(b1);
        b2 = new JButton("8");
        panel.add(b2);
        b3 = new JButton("9");
        panel.add(b3);
        b4 = new JButton("*");
        panel.add(b4);
        b5 = new JButton("4");
        panel.add(b5);
        b6 = new JButton("5");
        panel.add(b6);
        b7 = new JButton("6");
        panel.add(b7);
        b8 = new JButton("/");
        panel.add(b8);
        b9 = new JButton("1");
        panel.add(b9);
        b10 = new JButton("2");
        panel.add(b10);
        b11 = new JButton("3");
        panel.add(b11);
        b12 = new JButton("+");
        panel.add(b12);
        b13 = new JButton("0");
        panel.add(b13);
        b14 = new JButton(".");
        panel.add(b14);
        b15 = new JButton("=");
        panel.add(b15);
        b16 = new JButton("-");
        panel.add(b16);

        container.add (panel, BorderLayout.CENTER);

        setSize(300, 300);
        setVisible(true);
    }

    public static void main(String[] args) {
        Thirteen app = new Thirteen();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}