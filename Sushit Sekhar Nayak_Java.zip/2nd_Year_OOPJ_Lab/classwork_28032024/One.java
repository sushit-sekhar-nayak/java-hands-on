// Create a Window with following features:
// a. Window size is 300x300
// b. The command for the default close operation
// button is shutting down the JVM.
// c. The title of the window is "My First Frame".

import java.awt.*;
import javax.swing.*;

public class One extends JFrame {
    public One () {
        super ("My First Frame");

        Container container = getContentPane();
        container.setLayout(new FlowLayout());

        setSize(300, 300);
        setVisible(true);
    }
    public static void main (String args[]) {
        One app = new One();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}