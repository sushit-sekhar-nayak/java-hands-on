import java.awt.*;
import javax.swing.*;

public class Nine extends JFrame {
    private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16;

    public Nine () {

        super ("Calculator");

        Container container = getContentPane();
        container.setLayout(new GridLayout(4, 4, 10, 10));

        b1 = new JButton("7");
        container.add(b1);
        b2 = new JButton("8");
        container.add(b2);
        b3 = new JButton("9");
        container.add(b3);
        b4 = new JButton("*");
        container.add(b4);
        b5 = new JButton("4");
        container.add(b5);
        b6 = new JButton("5");
        container.add(b6);
        b7 = new JButton("6");
        container.add(b7);
        b8 = new JButton("/");
        container.add(b8);
        b9 = new JButton("1");
        container.add(b9);
        b10 = new JButton("2");
        container.add(b10);
        b11 = new JButton("3");
        container.add(b11);
        b12 = new JButton("+");
        container.add(b12);
        b13 = new JButton("0");
        container.add(b13);
        b14 = new JButton(".");
        container.add(b14);
        b15 = new JButton("=");
        container.add(b15);
        b16 = new JButton("-");
        container.add(b16);

        setSize(300, 250);
        setVisible(true);
    }

    public static void main(String[] args) {
        Nine app = new Nine();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}