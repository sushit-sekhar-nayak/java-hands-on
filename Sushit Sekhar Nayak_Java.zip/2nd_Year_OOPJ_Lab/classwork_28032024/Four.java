import java.awt.*;
import javax.swing.*;

public class Four extends JFrame {
    private JLabel label1, label2;

    public Four () {
        super ("My First Frame");

        label1 = new JLabel("This is the North Border", SwingConstants.CENTER);
        add(label1, BorderLayout.NORTH);
        label1.setFont(new Font("", 1, 20));

        label2 = new JLabel("This is the South Border", SwingConstants.CENTER);
        add(label2, BorderLayout.SOUTH);
        label2.setFont(new Font("", 1, 20));

        setSize(400, 200);
        setVisible(true);
    }
    public static void main (String args[]) {
        Four app = new Four();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}