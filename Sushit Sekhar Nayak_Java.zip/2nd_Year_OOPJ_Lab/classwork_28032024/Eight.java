import java.awt.*;
import javax.swing.*;

public class Eight extends JFrame {
    private JButton b1, b2, b3, b4;

    public Eight () {

        super ("GridLayout Window");

        Container container = getContentPane();
        container.setLayout(new GridLayout(2, 2));

        b1 = new JButton("Button 1");
        container.add(b1);
        b2 = new JButton("Button 2");
        container.add(b2);
        b3 = new JButton("Button 3");
        container.add(b3);
        b4 = new JButton("Button 4");
        container.add(b4);
        

        setSize(300, 300);
        setVisible(true);
    }

    public static void main(String[] args) {
        Eight app = new Eight();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}