import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class ThirtyTwo extends JFrame {
    private JSlider invertedSlider, tickedSlider, horizontalSlider;

    public ThirtyTwo() {
        setTitle("Slider Types Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLayout(new GridLayout(3, 1, 10, 10));

        // Border styles
        Border border = BorderFactory.createEmptyBorder(10, 10, 10, 10);
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "JSlider Without Tick Marks", TitledBorder.LEFT, TitledBorder.TOP);
        TitledBorder titledBorder2 = BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "JSlider With Tick Marks", TitledBorder.LEFT, TitledBorder.TOP);
        TitledBorder titledBorder3 = BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "JSlider With Tick Marks and Labels", TitledBorder.LEFT, TitledBorder.TOP);

        invertedSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
        tickedSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
        horizontalSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);

        invertedSlider.setInverted(true);
        tickedSlider.setPaintTicks(true);
        tickedSlider.setMajorTickSpacing(10);
        horizontalSlider.setPaintTicks(true);
        horizontalSlider.setPaintLabels(true);
        horizontalSlider.setMajorTickSpacing(10);
        horizontalSlider.setMinorTickSpacing(5);

        JPanel panel1 = new JPanel(new BorderLayout());
        panel1.setBorder(BorderFactory.createCompoundBorder(border, titledBorder1));
        panel1.add(invertedSlider, BorderLayout.CENTER);

        JPanel panel2 = new JPanel(new BorderLayout());
        panel2.setBorder(BorderFactory.createCompoundBorder(border, titledBorder2));
        panel2.add(tickedSlider, BorderLayout.CENTER);

        JPanel panel3 = new JPanel(new BorderLayout());
        panel3.setBorder(BorderFactory.createCompoundBorder(border, titledBorder3));
        panel3.add(horizontalSlider, BorderLayout.CENTER);

        add(panel1);
        add(panel2);
        add(panel3);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ThirtyTwo::new);
    }
}