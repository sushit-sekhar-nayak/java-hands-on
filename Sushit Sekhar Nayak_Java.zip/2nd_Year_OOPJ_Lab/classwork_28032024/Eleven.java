import java.awt.*;
import javax.swing.*;

public class Eleven extends JFrame {
    private JButton east, west, north, south, center;

    public Eleven () {
        super ("JPanel is a Container");

        east = new JButton("East");
        add(east, BorderLayout.EAST);
        west = new JButton("West");
        add(west, BorderLayout.WEST);
        north = new JButton("North");
        add(north, BorderLayout.NORTH);
        south = new JButton("South");
        add(south, BorderLayout.SOUTH);
        
        JPanel centerPanel = new JPanel(new GridLayout(2, 2));
        centerPanel.add (new JButton("Button1"));
        centerPanel.add (new JButton("Button2"));
        centerPanel.add (new JButton("Button3"));
        centerPanel.add (new JButton("Button4"));

        add (centerPanel, BorderLayout.CENTER);

        setSize(350, 250);
        setVisible(true);
    }
    public static void main (String args[]) {
        Eleven app = new Eleven();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}