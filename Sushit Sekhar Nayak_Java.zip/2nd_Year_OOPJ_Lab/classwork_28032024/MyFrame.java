import javax.swing.*;

class MyFrame extends JPanel {
    MyFrame() {
        setSize(200, 200);
        // Default layout of the JPanel is "FlowLayout"
        add(new JButton("Button1"));
        add(new JButton("Button2"));
        add(new JButton("Button3"));
        add(new JButton("Button4"));
    }

    public static void main(String args[]) {
        new MyFrame().setVisible(true);
    }
}