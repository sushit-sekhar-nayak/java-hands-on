// Given an array of integers, find the number of sub array having sum exactly equal to a given number x in O(n) time complexity.\

#include<stdio.h>

int countSubarray (int arr[], int n, int x) {
    int count = 0;
    for (int i=0; i<n; i++) {
        int sum=0;
        for (int j=i; j<n; j++) {
            sum += arr[j];
            if (sum == x) {
                count++;
            }
        }
    }
    return count;
}

int main () {

    int n;
    printf ("Enter the size of Array : ");
    scanf ("%d", &n);

    int arr[n];
    printf ("Enter the elements of array below-\n");
    for (int i=0; i<n; i++) {
        scanf("%d", &arr[i]);
    }

    int x;
    printf ("Enter the value x : ");
    scanf("%d", &x);

    printf ("The number of subarrays are : %d", countSubarray (arr, n, x));

    return 0;
}