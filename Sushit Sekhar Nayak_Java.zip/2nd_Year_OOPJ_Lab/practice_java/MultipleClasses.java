class One {
    void printOne() {
        System.out.println ("Class One is executed successfully!");
    }
}

class Two {
    void printTwo () {
        System.out.println ("Class Two is executed successfully!");
    }
}

class Three {
    void printThree () {
        System.out.print ("Class Three is executed successfully!");
    }
}

public class MultipleClasses {
    public static void main (String args[]) {
        One a = new One();
        Two b = new Two();
        Three c = new Three();

        a.printOne();
        b.printTwo();
        c.printThree();
    }
}