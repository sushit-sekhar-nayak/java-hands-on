class test {
    int value;
}

public class object {
    public static void main (String args[]) {
    test t1 = new test();
    test t2 = new test();
    t1.value = 10;
    t2.value = 30;
    t2 = t1;
    System.out.print (t1.value + " " + t2.value);
    }
}