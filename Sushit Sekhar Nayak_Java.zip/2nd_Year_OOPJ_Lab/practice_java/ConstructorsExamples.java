class Student {
    int a;
    String s;
    void print () {
        System.out.println (a + " " + s);
    }
}

public class ConstructorsExamples {
    public static void main (String args[]) {
        Student s1 = new Student();
        Student s2 = new Student();
        s1.print();
        s2.print();
    }
}