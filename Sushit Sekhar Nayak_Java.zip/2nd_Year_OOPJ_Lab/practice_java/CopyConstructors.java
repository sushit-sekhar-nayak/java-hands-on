class One {
    int x;
    String s;
    One (int a, String str) {
        x = a;
        s = str;
    }
    One (One object) {
        x = object.x;
        s = object.s;
    }
    void print () {
        System.out.println (x + " " + s);
    }
}

public class CopyConstructors {
    public static void main(String[] args) {
        One obj = new One(100, "Sushit");
        obj.print ();
        One obj2 = new One(obj);
        obj2.print ();
    }
}