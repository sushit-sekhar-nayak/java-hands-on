class A {
    int a = 10;
    void display () {
        System.out.println ("Class A Executed!");
    }
}

class B extends A {
    int a = 20;
    void display() {
        System.out.println ("Class B Executed!");
        super.display();
    }
}

public class MethodOverriding {
    public static void main (String args[]) {
        B r = new B();
        r.display();
    }
}