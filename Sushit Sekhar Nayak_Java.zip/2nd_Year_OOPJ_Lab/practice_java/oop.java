class A {
    int a;
    double b;
    String c;
    A () {
        a = 3;
        b = 3.412;
        c = "Sushit";
    }
    A (int x) {
        a = x;
    }
    A (double y, String z) {
        b = y;
        c = z;
    }
}

public class oop {
    public static void main (String args[]) {
        A obj1 = new A(30);
        A obj2 = new A(12.34, "Sekhar");
        A obj3 = new A();
        System.out.println (obj1.a);
        System.out.println (obj3.a + " " + obj3.b + " " + obj3.c);
        System.out.println (obj2.b + " " + obj2.c);
    }
}