import java.util.*;

public class Student {
    int id;
    String name;
    Student (Scanner input) {
        System.out.print ("Enter your ID : ");
        id = input.nextInt();
        input.nextLine();
        System.out.print ("Enter your Name : ");
        name = input.nextLine();
    }
    void display () {
        System.out.println(id+" "+name);
    }
    public static void main (String args[]) {
        Scanner input = new Scanner(System.in);
        System.out.println ("Enter Details for Student 1-");
        Student s1 = new Student(input);
        System.out.println ("Enter Details for Student2 -");
        Student s2 = new Student(input);
        s1.display();
        s2.display();
    }
}