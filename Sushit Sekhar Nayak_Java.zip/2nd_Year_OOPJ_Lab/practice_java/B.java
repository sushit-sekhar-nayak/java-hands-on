import java.util.Scanner;

public class B {

    void swap (int *x, int *y) {
        int *temp = x;
        x = y;
        y = temp;
    }

    void sort (int arr[]) {
        for (int i=0; i<arr.length-1; i++) {
            for (int j=i+1; j<arr.length; j++) {
                if (arr[j] > arr[j+1]) {
                    swap (&arr[j], &arr[j+1]);
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50, 60, 70, 10};
        B obj = new B();
        arr = obj.sort(arr);
    }
}