import java.awt.*;
import javax.swing.*;
class MyFrame extends JFrame{
private JLabel titleLabel;
MyFrame(){
setSize(200,100);
setDefaultCloseOperation(EXIT_ON_CLOSE);
setTitle("Demonstrate JLabel");
titleLabel=new JLabel("This is a JLabel");
add("North",titleLabel);
}
public static void main(String args[]) {
new MyFrame().setVisible(true);
}
}