import java.util.Scanner;

public class A {

    public static void main (String args[]) {
        int arr[] = new int[5];
        System.out.print("Array is : ");
        for (int i=0; i<arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}