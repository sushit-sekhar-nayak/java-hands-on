public class MethodOverloading {
    static void function (int n) {
        System.out.println ("First function is executed.");
        System.out.println ("Data: " + n);
    }
    static void function (String s) {
        System.out.println ("Second Function is executed.");
        System.out.print ("Data: " + s);
    }
    public static void main (String args[]) {
        function (30);
        function ("Sushit");
    }
}