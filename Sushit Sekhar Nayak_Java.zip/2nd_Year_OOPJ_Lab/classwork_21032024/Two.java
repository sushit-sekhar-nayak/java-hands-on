// Write a Java program to showcase the usage of the CyclicBarrier class for thread synchronization.

// Write a Java program to showcase the usage of the CyclicBarrier class for thread synchronization.


import java.util.concurrent.CyclicBarrier;

class WorkerThread implements Runnable {
    private CyclicBarrier barrier;

    public WorkerThread(CyclicBarrier barrier) {
        this.barrier = barrier;
    }

    @Override
    public void run() {
        try {
            System.out.println(Thread.currentThread().getName() + " is waiting on barrier");
            barrier.await();
            System.out.println(Thread.currentThread().getName() + " has crossed the barrier");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

public class Two {
    public static void main(String[] args) {
        final int numberOfThreads = 3;
        final CyclicBarrier barrier = new CyclicBarrier(numberOfThreads, () -> {
            System.out.println("All threads have reached the barrier, let's proceed!");
        });

        for (int i = 1; i <= numberOfThreads; i++) {
            Thread thread = new Thread(new WorkerThread(barrier), "Thread " + i);
            thread.start();
        }
    }
}