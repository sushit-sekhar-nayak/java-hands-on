import java.util.*;
import java.util.concurrent.Semaphore;


class SharedResource {
    static Semaphore semaphore = new Semaphore(1);

    static void useResource() throws InterruptedException {
        semaphore.acquire();
        System.out.println(Thread.currentThread().getName() + " is using the shared resource.");
        Thread.sleep(1000);
        semaphore.release(); 
        System.out.println(Thread.currentThread().getName() + " released the shared resource.");
    }
}

class MyThread extends Thread {
    SharedResource sharedResource;

    MyThread(SharedResource sharedResource, String name) {
        super(name);
        this.sharedResource = sharedResource;
    }

    public void run() {
        System.out.println(Thread.currentThread().getName() + " started.");
        try {
            sharedResource.useResource(); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName() + " finished.");
    }
}

public class One {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        MyThread thread1 = new MyThread(sharedResource, "Thread 1");
        MyThread thread2 = new MyThread(sharedResource, "Thread 2");

        thread1.start();
        thread2.start();
    }
}