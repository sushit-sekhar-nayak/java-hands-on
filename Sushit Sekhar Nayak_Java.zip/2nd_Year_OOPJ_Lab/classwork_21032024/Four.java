//Write a Java program to illustrate the usage of the ReadWriteLock interface for concurrent read-write access to a shared resource. 

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class SharedResource {
    private int counter = 0;
    private ReadWriteLock lock = new ReentrantReadWriteLock();

    public void incrementCounter() {
        lock.writeLock().lock();
        try {
            counter++;
            System.out.println("Incremented counter to " + counter + " by " + Thread.currentThread().getName());
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void printCounter() {
        lock.readLock().lock();
        try {
            System.out.println("Counter: " + counter + " read by " + Thread.currentThread().getName());
        } finally {
            lock.readLock().unlock();
        }
    }
}

public class Four {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        // Create and start writer threads
        Thread writer1 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                sharedResource.incrementCounter();
            }
        }, "Writer-1");

        Thread writer2 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                sharedResource.incrementCounter();
            }
        }, "Writer-2");

        writer1.start();
        writer2.start();

        // Create and start reader threads
        Thread reader1 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                sharedResource.printCounter();
            }
        }, "Reader-1");

        Thread reader2 = new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                sharedResource.printCounter();
            }
        }, "Reader-2");

        reader1.start();
        reader2.start();
    }
}