import java.util.concurrent.ConcurrentHashMap;

public class Five {
    public static void main(String[] args) {
        
        ConcurrentHashMap<Integer, String> concurrentMap = new ConcurrentHashMap<>();

        concurrentMap.put(1, "One");
        concurrentMap.put(2, "Two");
        concurrentMap.put(3, "Three");

     
        Thread writerThread = new Thread(() -> {
            for (int i = 4; i <= 6; i++) {
                concurrentMap.put(i, "Value" + i);
                System.out.println("Added: " + i);
            }
        });

        Thread readerThread = new Thread(() -> {
            for (int i = 1; i <= 6; i++) {
                System.out.println("Value for key " + i + ": " + concurrentMap.get(i));
            }
        });

        writerThread.start();
        readerThread.start();

        try {

            writerThread.join();
            readerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}