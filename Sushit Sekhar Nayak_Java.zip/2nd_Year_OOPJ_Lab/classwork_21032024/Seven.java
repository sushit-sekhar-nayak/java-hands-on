import java.util.concurrent.Phaser;

class MyThread implements Runnable {
    private final Phaser phaser;
    private final String name;

    MyThread(Phaser phaser, String name) {
        this.phaser = phaser;
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println(name + " is waiting for other threads to start.");
        phaser.arriveAndAwaitAdvance(); // Wait for all threads to start

        // Perform some task
        System.out.println(name + " is performing its task.");

        // Signal completion
        phaser.arriveAndDeregister(); // Signal that this thread has completed
    }
}

public class Seven {
    public static void main(String[] args) {
        Phaser phaser = new Phaser(1); // Initialize with 1 registered party (main thread)

        // Create and start threads
        for (int i = 1; i <= 3; i++) {
            String threadName = "Thread " + i;
            phaser.register(); // Register each thread with the phaser
            new Thread(new MyThread(phaser, threadName)).start();
        }

        // Allow threads to start
        phaser.arriveAndDeregister(); // Signal all registered parties (threads) to start

        // Wait for all threads to complete
        while (!phaser.isTerminated()) {
            phaser.arriveAndAwaitAdvance(); // Wait for all threads to complete
        }

        System.out.println("All threads have completed their tasks.");
    }
}
