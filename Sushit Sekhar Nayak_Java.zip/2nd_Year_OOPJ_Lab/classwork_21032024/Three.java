import java.util.concurrent.CountDownLatch;

class Worker implements Runnable {
    private final CountDownLatch startSignal;
    private final CountDownLatch doneSignal;

    Worker(CountDownLatch startSignal, CountDownLatch doneSignal) {
        this.startSignal = startSignal;
        this.doneSignal = doneSignal;
    }

    @Override
    public void run() {
        try {
            startSignal.await();  
            System.out.println(Thread.currentThread().getName() + " is working");
            doneSignal.countDown(); 
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

public class Three {
    public static void main(String[] args) throws InterruptedException {
        int N = 3;

        CountDownLatch startSignal = new CountDownLatch(1);
        CountDownLatch doneSignal = new CountDownLatch(N);

        for (int i = 0; i < N; ++i) {
            new Thread(new Worker(startSignal, doneSignal)).start();
        }

        System.out.println("All worker threads created. Starting work...");
        startSignal.countDown(); 

        System.out.println("Waiting for all workers to finish...");
        doneSignal.await(); 

        System.out.println("All workers finished.");
    }
}