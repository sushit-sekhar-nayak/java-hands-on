import java.util.concurrent.ConcurrentLinkedQueue;

public class Six {
    public static void main(String[] args) {
        
        ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<>();


        Producer producer = new Producer(queue);
        Consumer consumer = new Consumer(queue);

        
        producer.start();
        consumer.start();
    }
}

class Producer extends Thread {
    private final ConcurrentLinkedQueue<Integer> queue;

    public Producer(ConcurrentLinkedQueue<Integer> queue) {
        this.queue = queue;
    }

    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                queue.add(i);
                System.out.println("Produced: " + i);
                Thread.sleep(100); 
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class Consumer extends Thread {
    private final ConcurrentLinkedQueue<Integer> queue;

    public Consumer(ConcurrentLinkedQueue<Integer> queue) {
        this.queue = queue;
    }

    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                if (!queue.isEmpty()) {
                    int value = queue.poll();
                    System.out.println("Consumed: " + value);
                } else {
                    System.out.println("Queue is empty, waiting...");
                }
                Thread.sleep(200); // Simulating some processing time
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}