public class Demo {
    public static void main (String args []) {
        String sql = "select first_name from Employee2 where id=8";
        
    }
}