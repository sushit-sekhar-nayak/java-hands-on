// Write a Java program to handle an ArithmeticException using try, catch, and finally block.

import java.util.*;

public class Two {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the Dividend : ");
        int dividend = input.nextInt();
        System.out.print ("Enter the Divisor : ");
        int divisor = input.nextInt();
        try {
            int result = dividend/divisor;
            System.out.println ("The Result is : " + result);
        }
        catch (ArithmeticException e) {
            System.out.println (e);
        }
        finally {
            System.out.print ("The Finally Block is being executed...");
        }
    }
}