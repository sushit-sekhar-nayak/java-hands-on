import java.util.Scanner;

class HrsException extends Exception {
    public HrsException (String message) {
        super (message);
    }
}

class MinException extends Exception {
    public MinException (String message) {
        super (message);
    }
}

class SecException extends Exception {
    public SecException (String message) {
        super (message);
    }
}

class Time {
    private int hours;
    private int minutes;
    private int seconds;

    public Time (int hours, int minutes, int seconds) {
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    public static Time getTimeFromUser() throws HrsException, MinException, SecException {
        Scanner scanner = new Scanner(System.in);
        System.out.print ("Enter hours: ");
        int hours = scanner.nextInt();
        

        System.out.print ("Enter minutes: ");
        int minutes = scanner.nextInt();
        

        System.out.print("Enter seconds: ");
        int seconds = scanner.nextInt();
        
        if (hours < 0 || hours > 24) {
            throw new HrsException ("InvalidHourException: Hour should be between 0 and 24");
        }
        if (minutes < 0 || minutes > 60) {
            throw new MinException("InvalidMinuteException: Minutes should be between 0 and 60");
        }
        if (seconds < 0 || seconds > 60) {
            throw new SecException ("InvalidSecondException: Seconds should be between 0 and 60");
        }

        return new Time (hours, minutes, seconds);
    }

    @Override
    public String toString () {
        return hours + ":" + minutes + ":" + seconds;
    }
}

public class Four {
    public static void main(String[] args) {
        try {
            Time time = Time.getTimeFromUser();
            System.out.println("Correct Time -> " + time);
        }
        catch (HrsException | MinException | SecException e) {
            System.out.println("Caught the exception");
            System.out.println("Exception occurred: " + e.getMessage());
        }
    }
}