// Write a Java class which has a method called ProcessInput(). This method checks the number entered by the user. If the entered number is negative then throw an user defined exception called NegativeNumberException, otherwise it displays the double value of the entered number.

import java.util.*;

class NegativeNumberException extends Exception {
    NegativeNumberException (String s) {
        super (s);
    }
}

public class Three {

    static void validate (int number) throws NegativeNumberException {
        if (number < 0) {
            throw new NegativeNumberException("Number should be Positive");
        }
        else {
            System.out.print ("Double Value : " + (2*number));
        }
    }
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the number : ");
        int num = input.nextInt();

        try {
            validate (num);
        }
        catch (Exception m) {
            System.out.println ("Exception Occured : " + m);
        }
    }
}