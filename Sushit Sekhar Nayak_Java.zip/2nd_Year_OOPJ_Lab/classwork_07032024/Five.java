// Create an user defined exception named CheckArgument to check the number of arguments passed through command line. If the number of arguments is less than four then throw the Check Argument exception, else print the addition of squares of all the four elements.

class CheckArgumentException extends Exception {
    public CheckArgumentException (String message) {
        super(message);
    }
}

public class Five {
    public static void main(String[] args) {
        try {
            if (args.length < 4) {
                throw new CheckArgumentException ("Exception occurred - CheckArgument");
            }
            else {
                int sumOfSquares = 0;
                for (String arg : args) {
                    int num = Integer.parseInt(arg);
                    sumOfSquares += num * num;
                }
                System.out.println ("Sum of Squares: " +sumOfSquares);
            }
        }
        catch (CheckArgumentException e) {
            System.out.println (e.getMessage());
        }
    }
}