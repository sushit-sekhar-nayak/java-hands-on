import java.util.Arrays;
import java.util.Scanner;
public class One {
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
System.out.print("Enter the size of array A: ");
int sizeA = input.nextInt();
int[] A = new int[sizeA];
System.out.println("Enter the elements of array A in ascending order:");
for (int i = 0; i < sizeA; i++) {
A[i] = input.nextInt();
}
System.out.print("Enter the size of array B: ");
int sizeB = input.nextInt();
int[] B = new int[sizeB];
System.out.println("Enter the elements of array B in ascending order:");
for (int i = 0; i < sizeB; i++) {
B[i] = input.nextInt();
}
int[] C = mergeArrays(A, B);
System.out.print("Merged Sorted Array C: ");
for (int num : C) {
System.out.print(num + " ");
}
input.close();
}
public static int[] mergeArrays(int[] A, int[] B) {
int m = A.length;
int n = B.length;
int[] C = new int[m + n];
int i = 0, j = 0, k = 0;
while (i < m && j < n) {
if (A[i] < B[j]) {
C[k++] = A[i++];
} else {
C[k++] = B[j++];
}
}
while (i < m) {
C[k++] = A[i++];
}
while (j < n) {
C[k++] = B[j++];
}
return C;
}
}