import java.util.Scanner;

class Commission {
    int sales;
    double commission () {
        double commission = (double) sales*0.1;
        return commission;
    }
}

public class Six {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        Commission obj = new Commission ();
        System.out.print ("Enter the Sale : ");
        obj.sales = input.nextInt();
        if (obj.sales < 0) {
            System.out.print ("Enter Correct Value!");
            return;
        }
        System.out.print ("Your Commission is : " + obj.commission());
    }
}