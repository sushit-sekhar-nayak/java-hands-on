// Create a base class called “vehicle” that stores number of wheels and speed. Create the following derived classes – “car” that inherits “vehicle” and also stores number of passengers. “truck” that inherits “vehicle” and also stores the load limit. Write a main function to create objects of these two derived classes and display all the information about “car” and “truck”. Also compare the speed of these two vehicles - car and truck and display which one is faster

import java.util.*;

class Vehicle {
    protected int numWheels;
    protected double speed;
    public Vehicle (int numWheels, double speed) {
        this.numWheels = numWheels;
        this.speed = speed;
    }
    public void displayInfo () {
        System.out.println("Number of Wheels: " + numWheels);
        System.out.println("Speed: " + speed + " Km/h");
    }
}
class Car extends Vehicle {
    private int numPassengers;
    public Car(int numWheels, double speed, int numPassengers) {
        super(numWheels, speed);
        this.numPassengers = numPassengers;
    }
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Passengers: " + numPassengers);
    }
}

class Truck extends Vehicle {
    private double loadLimit;
    public Truck(int numWheels, double speed, double loadLimit) {
        super(numWheels, speed);
        this.loadLimit = loadLimit;
    }
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Load Limit: " + loadLimit + " tons");
    }
}

public class Fourteen {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of wheels for the car: ");
        int carWheels = scanner.nextInt();
        System.out.print("Enter the speed of the car (in Km/h): ");
        double carSpeed = scanner.nextDouble();
        System.out.print("Enter the number of passengers for the car: ");
        int carPassengers = scanner.nextInt();
        Car car = new Car(carWheels, carSpeed, carPassengers);
        System.out.print("Enter the number of wheels for the truck: ");
        int truckWheels = scanner.nextInt();
        System.out.print("Enter the speed of the truck (in Km/h): ");
        double truckSpeed = scanner.nextDouble();
        System.out.print("Enter the load limit for the truck (in tons): ");
        double truckLoadLimit = scanner.nextDouble();
        Truck truck = new Truck(truckWheels, truckSpeed, truckLoadLimit);
        System.out.println("\nInformation about Car:");
        car.displayInfo();
        System.out.println("\nInformation about Truck:");
        truck.displayInfo();
        if (car.speed > truck.speed) {
            System.out.println("\nThe car is faster than the truck.");
        } 
    
        else if (car.speed < truck.speed) {
            System.out.println("\nThe truck is faster than the car.");
        }
        
        else {
        System.out.println("\nThe car and truck have the same speed.");
        }

    }
}