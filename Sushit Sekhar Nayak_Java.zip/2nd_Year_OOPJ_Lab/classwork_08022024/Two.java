class ZeroArgument {
    ZeroArgument () {
        System.out.print ("The Zero Argument Constructor is invoked!");
    }
}

public class Two {
    public static void main (String args[]) {
        ZeroArgument obj = new ZeroArgument();
    }
}