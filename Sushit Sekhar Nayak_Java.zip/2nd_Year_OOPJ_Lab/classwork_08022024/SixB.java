// Write a program to create a class named Vehicle having protected instance variables regnNumber, speed, color, ownerName and a method showData ( ) to show “This is a vehicle class”. Inherit the Vehicle class into subclasses named Bus and Car having individual private instance variables routeNumber in Bus and manufacturerName in Car and both of them having showData ( ) method showing all details of Bus and Car respectively with content of the super class’s showData ( ) method.

import java.util.*;

class Vehicle {
    protected int regnNumber;
    protected int speed;
    protected String color;
    protected String ownerName;

    void showData() {
        System.out.println("This is a vehicle class");
    }

    void setDetails(int regnNumber, int speed, String color, String ownerName) {
        this.regnNumber = regnNumber;
        this.speed = speed;
        this.color = color;
        this.ownerName = ownerName;
    }
}

class Bus extends Vehicle {
    private int routeNumber;

    void setRouteNumber(int routeNumber) {
        this.routeNumber = routeNumber;
    }

    @Override
    void showData() {
        super.showData();
        System.out.println("Route Number: " + routeNumber);
        System.out.println("Registration Number: " + regnNumber);
        System.out.println("Speed: " + speed);
        System.out.println("Color: " + color);
        System.out.println("Owner Name: " + ownerName);
    }
}

class Car extends Vehicle {
    private String manufacturerName;

    void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    @Override
    void showData() {
        super.showData();
        System.out.println("Manufacturer Name: " + manufacturerName);
        System.out.println("Registration Number: " + regnNumber);
        System.out.println("Speed: " + speed);
        System.out.println("Color: " + color);
        System.out.println("Owner Name: " + ownerName);
    }
}

public class SixB {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);

        Bus myBus = new Bus();
        System.out.println("Enter Bus Registration Number:");
        int busRegnNumber = scanner.nextInt();
        System.out.println("Enter Bus Speed:");
        int busSpeed = scanner.nextInt();
        System.out.println("Enter Bus Color:");
        String busColor = scanner.next();
        System.out.println("Enter Bus Owner Name:");
        String busOwnerName = scanner.next();
        myBus.setDetails(busRegnNumber, busSpeed, busColor, busOwnerName);
        System.out.println("Enter Bus Route Number:");
        int busRouteNumber = scanner.nextInt();
        myBus.setRouteNumber(busRouteNumber);

        Car myCar = new Car();
        System.out.println("Enter Car Registration Number:");
        int carRegnNumber = scanner.nextInt();
        System.out.println("Enter Car Speed:");
        int carSpeed = scanner.nextInt();
        System.out.println("Enter Car Color:");
        String carColor = scanner.next();
        System.out.println("Enter Car Owner Name:");
        String carOwnerName = scanner.next();
        myCar.setDetails(carRegnNumber, carSpeed, carColor, carOwnerName);
        System.out.println("Enter Car Manufacturer Name:");
        String carManufacturerName = scanner.next();
        myCar.setManufacturerName(carManufacturerName);

        System.out.println("\nBus Details:");
        myBus.showData();

        System.out.println("\nCar Details:");
        myCar.showData();
    }
}