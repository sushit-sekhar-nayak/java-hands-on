// Create a general class ThreeDObject and derive the classes Box, Cube, Cylinder and Cone from it. The class ThreeDObject has methods wholeSurfaceArea ( ) and volume (). Override these two methods in each of the derived classes to calculate the volume and whole surface area of each type of three-dimensional objects. The dimensions of the objects are to be taken from the users and passed through the respective constructors of each derived class. Write a main method to test these classes.

import java.util.*;

class ThreeDObject {
    void wholeSurfaceArea() {
    }

    void volume() {
    }
}

class Box extends ThreeDObject {
    int length;
    int breadth;
    int height;

    Box(int l, int b, int h) {
        length = l;
        breadth = b;
        height = h;
    }

    void wholeSurfaceArea() {
        int surfaceArea = 2 * (length * breadth + breadth * height + height * length);
        System.out.println("Whole Surface Area of Box: " + surfaceArea);
    }

    void volume() {
        int vol = length * breadth * height;
        System.out.println("Volume of Box: " + vol);
    }
}

class Cube extends ThreeDObject {
    int side;

    Cube(int s) {
        side = s;
    }

    void wholeSurfaceArea() {
        int surfaceArea = 6 * side * side;
        System.out.println("Whole Surface Area of Cube: " + surfaceArea);
    }

    void volume() {
        int vol = side * side * side;
        System.out.println("Volume of Cube: " + vol);
    }
}

class Cylinder extends ThreeDObject {
    int radius;
    int height;

    Cylinder(int r, int h) {
        radius = r;
        height = h;
    }

    void wholeSurfaceArea() {
        double surfaceArea = 2 * Math.PI * radius * (radius + height);
        System.out.println("Whole Surface Area of Cylinder: " + surfaceArea);
    }

    void volume() {
        double vol = Math.PI * radius * radius * height;
        System.out.println("Volume of Cylinder: " + vol);
    }
}

class Cone extends ThreeDObject {
    int radius;
    int height;

    Cone(int r, int h) {
        radius = r;
        height = h;
    }

    void wholeSurfaceArea() {
        double surfaceArea = Math.PI * radius * (radius + Math.sqrt(radius * radius + height * height));
        System.out.println("Whole Surface Area of Cone: " + surfaceArea);
    }

    void volume() {
        double vol = Math.PI * radius * radius * height / 3.0;
        System.out.println("Volume of Cone: " + vol);
    }
}

public class SixA {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        System.out.println("Which Shape : ");
        System.out.println("1. Box");
        System.out.println("2. Cube");
        System.out.println("3. Cylinder");
        System.out.println("4. Cone");
        System.out.print("Enter your Choice : ");
        int choice = input.nextInt();
        switch (choice) {
            case 1:
                System.out.print("Enter Length : ");
                int length = input.nextInt();
                System.out.print("Enter Breadth : ");
                int breadth = input.nextInt();
                System.out.print("Enter Height : ");
                int height = input.nextInt();
                Box box = new Box(length, breadth, height);
                box.wholeSurfaceArea();
                box.volume();
                break;
            case 2:
                System.out.print("Enter Side : ");
                int side = input.nextInt();
                Cube cube = new Cube(side);
                cube.wholeSurfaceArea();
                cube.volume();
                break;
            case 3:
                System.out.print("Enter Radius : ");
                int radius = input.nextInt();
                System.out.print("Enter Height : ");
                int cylHeight = input.nextInt();
                Cylinder cylinder = new Cylinder(radius, cylHeight);
                cylinder.wholeSurfaceArea();
                cylinder.volume();
                break;
            case 4:
                System.out.print("Enter Radius : ");
                int coneRadius = input.nextInt();
                System.out.print("Enter Height : ");
                int coneHeight = input.nextInt();
                Cone cone = new Cone(coneRadius, coneHeight);
                cone.wholeSurfaceArea();
                cone.volume();
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
}