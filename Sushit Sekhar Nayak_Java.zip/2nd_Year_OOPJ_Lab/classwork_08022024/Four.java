class ConstructorOverloading {
    ConstructorOverloading () {
        System.out.println("1st one is invoked!");
    }
    ConstructorOverloading (int a) {
        System.out.println ("2nd One is invoked!");
    }
    ConstructorOverloading (int a, int b) {
        System.out.println ("3rd one is invoked");
    }
}

public class Four {
    public static void main (String args[]) {
        ConstructorOverloading obj1 = new ConstructorOverloading();
        ConstructorOverloading obj2 = new ConstructorOverloading(100);
        ConstructorOverloading obj3 = new ConstructorOverloading(10, 20);
    }
}