// Write a class Account containing acc_no, balance as data members and two methods as input() for taking input from user and disp() method to display the details. Create a subclass Person which has name and aadhar_no as extra data members and override disp() function. Write the complete progrm to take and print details of three persons.

import java.util.*;

class Account {
    private int acc_no;
    private double balance;

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Account Number: ");
        acc_no = scanner.nextInt();
        System.out.print("Enter Balance: ");
        balance = scanner.nextDouble();
    }

    public void disp() {
        System.out.println("Account Number: " + acc_no);
        System.out.println("Balance: " + balance);
    }
}

class Person extends Account {
    private String name;
    private String aadhar_no;

    @Override
    public void disp() {
        super.disp();
        System.out.println("Name: " + name);
        System.out.println("Aadhar Number: " + aadhar_no);
    }

    public void inputPerson() {
        Scanner scanner = new Scanner(System.in);
        super.input();
        System.out.print("Enter Name: ");
        name = scanner.nextLine();
        System.out.print("Enter Aadhar Number: ");
        aadhar_no = scanner.nextLine();
    }
}

public class Eighteen {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        Person[] persons = new Person[3];

        for (int i = 0; i < 3; i++) {
            System.out.println("Enter Details for Person " + (i + 1) + ":");
            persons[i] = new Person();
            persons[i].inputPerson();
        }

        System.out.println("\nDetails of Persons:");
        for (int i = 0; i < 3; i++) {
            System.out.println("\nDetails for Person " + (i + 1) + ":");
            persons[i].disp();
        }
    }
}