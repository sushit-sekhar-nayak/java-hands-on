// Write a class, Grader, which has an instance variable, score, an appropriate constructor and appropriate methods. A method, letterGrade() that returns the letter grade as O/E/A/B/C/F.

import java.util.*;

class Grader {
    int score;
    char letterGrade () {
        if (score>=90 && score<=100)
            return 'O';
        else if (score>=80 && score<90)
            return 'E';
        else if (score>=70 && score<80)
            return 'A';
        else if (score>=60 && score<70)
            return 'B';
        else if (score>=50 && score<60)
            return 'C';
        else
            return 'F';
    }
}

public class Five {
    public static void main (String args[]) {
        Scanner input = new Scanner(System.in);
        Grader obj = new Grader();
        System.out.print ("Enter Your score out of 100 : ");
        obj.score = input.nextInt();
        if (obj.score<0 || obj.score>100) {
            System.out.print ("Enter Correct Value!");
            return;
        }
        System.out.print ("You secured Grade : " + obj.letterGrade());
    }
}