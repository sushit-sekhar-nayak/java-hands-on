class ParametrizedConstructor {
    ParametrizedConstructor (int a) {
        System.out.print ("The Parametrized Constructor is invoked!");
    }
}

public class Three {
    public static void main (String args[]) {
        ParametrizedConstructor obj = new ParametrizedConstructor(100);
    }
}