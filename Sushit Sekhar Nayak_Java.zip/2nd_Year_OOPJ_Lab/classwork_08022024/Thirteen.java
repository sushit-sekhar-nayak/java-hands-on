// Create a base class Distance which stores the distance between two locations in miles and a method travelTime(). The method prints the time taken to cover the distance when the speed is 60 miles per hour. Now in a derived class DistanceMKS, override travelTime() so that it prints the time assuming the distance is in kilometers and the speed is 100 km per second. Demonstrate the working of the classes.

import java.util.*;

class Distance {
    protected double distance;
    public Distance (double distance) {
        this.distance = distance;
    }
    public void travelTime () {
        double speedInMilesPerHour = 60.0;
        double time = distance / speedInMilesPerHour;
        System.out.println("Time taken to cover the distance: " + time + " hours");
    }
}
    
class DistanceMKS extends Distance {
    public DistanceMKS (double distance) {
        super(distance);
    }
    @Override
    public void travelTime() {
        double speedInKilometersPerSecond = 100.0;
        double time = distance / speedInKilometersPerSecond;
        System.out.println("Time taken to cover the distance (MKS): " + time + "seconds");
    }
}
    
public class Thirteen {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the distance in miles: ");
        double distanceInMiles = scanner.nextDouble();
        Distance distance = new Distance(distanceInMiles);
        DistanceMKS distanceMKS = new DistanceMKS(distanceInMiles);
        System.out.println("\nTravel Time Calculation (Distance in Miles):");
        distance.travelTime();
        System.out.println("\nTravel Time Calculation (Distance in Kilometers):");
        distanceMKS.travelTime();
    }
}