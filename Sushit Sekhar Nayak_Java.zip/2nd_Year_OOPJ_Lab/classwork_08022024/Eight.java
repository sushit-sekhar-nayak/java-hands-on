// Create a base class Building that stores the number of floors of a building, number of rooms and it’s total footage. Create a derived class House that inherits Building and also stores the number of bedrooms and bathrooms. Demonstrate the working of the classes.

import java.util.*;

class Building {
    private int numFloors;
    private int numRooms;
    private double totalFootage;

    public Building(int numFloors, int numRooms, double totalFootage) {
        this.numFloors = numFloors;
        this.numRooms = numRooms;
        this.totalFootage = totalFootage;
    }

    public void displayInfo() {
        System.out.println("Number of Floors: " + numFloors);
        System.out.println("Number of Rooms: " + numRooms);
        System.out.println("Total Footage: " + totalFootage + " sq. ft");
    }
}

class House extends Building {
    private int numBedrooms;
    private int numBathrooms;

    public House(int numFloors, int numRooms, double totalFootage, int numBedrooms, int numBathrooms) {
        super(numFloors, numRooms, totalFootage);
        this.numBedrooms = numBedrooms;
        this.numBathrooms = numBathrooms;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Bedrooms: " + numBedrooms);
        System.out.println("Number of Bathrooms: " + numBathrooms);
    }
}

public class Eight {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Building Details:");
        System.out.print("Enter Number of Floors: ");
        int numFloorsBuilding = scanner.nextInt();
        System.out.print("Enter Number of Rooms: ");
        int numRoomsBuilding = scanner.nextInt();
        System.out.print("Enter Total Footage: ");
        double totalFootageBuilding = scanner.nextDouble();
        Building building = new Building(numFloorsBuilding, numRoomsBuilding, totalFootageBuilding);

        System.out.println("\nEnter House Details:");
        System.out.print("Enter Number of Bedrooms: ");
        int numBedroomsHouse = scanner.nextInt();
        System.out.print("Enter Number of Bathrooms: ");
        int numBathroomsHouse = scanner.nextInt();
        System.out.print("Enter Number of Floors: ");
        int numFloorsHouse = scanner.nextInt();
        System.out.print("Enter Number of Rooms: ");
        int numRoomsHouse = scanner.nextInt();
        System.out.print("Enter Total Footage: ");
        double totalFootageHouse = scanner.nextDouble();
        House house = new House(numFloorsHouse, numRoomsHouse, totalFootageHouse, numBedroomsHouse, numBathroomsHouse);

        System.out.println("\nBuilding Information:");
        building.displayInfo();
        System.out.println("\nHouse Information:");
        house.displayInfo();
    }
}