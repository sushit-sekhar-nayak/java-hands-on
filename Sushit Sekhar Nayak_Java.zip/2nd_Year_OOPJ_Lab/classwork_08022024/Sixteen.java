// Illustrate the execution of constructors in multi-level  inheritance with three Java classes – plate(length, width), box(length, width, height), wood box (length, width, height, thick) where box inherits from plate and woodbox inherits from box class. Each class has constructor where dimensions are taken from user.

import java.util.*;

class Plate {
    protected double length;
    protected double width;
    public Plate(double length, double width) {
        this.length = length;
        this.width = width;
        System.out.println("Plate constructor executed with length = " + length + "and width = " + width);
    }
}
    
class Box extends Plate {
    protected double height;
    public Box (double length, double width, double height) {
        super(length, width);
        this.height = height;
        System.out.println("Box constructor executed with length = " + length +", width = " + width + ", and height = " + height);
    }
}
    
class WoodBox extends Box {
    protected double thickness;
    public WoodBox(double length, double width, double height, double thickness) {
        super(length, width, height);
        this.thickness = thickness;
        System.out.println("WoodBox constructor executed with length = " + length +", width = " + width + ", height = " + height + ", and thickness = "+ thickness);
    }
}
    
public class Sixteen {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the length of the wood box: ");
        double woodBoxLength = scanner.nextDouble();
        System.out.print("Enter the width of the wood box: ");
        double woodBoxWidth = scanner.nextDouble();
        System.out.print("Enter the height of the wood box: ");
        double woodBoxHeight = scanner.nextDouble();
        System.out.print("Enter the thickness of the wood box: ");
        double woodBoxThickness = scanner.nextDouble();
        WoodBox woodBox = new WoodBox(woodBoxLength, woodBoxWidth, woodBoxHeight, woodBoxThickness);
    }
}