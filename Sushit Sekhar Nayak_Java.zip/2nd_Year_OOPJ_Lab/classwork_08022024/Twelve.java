import java.util.*;

class Num {
    protected int number;
    public Num(int number) {
        this.number = number;
    }
    public void showNum() {
        System.out.println("Number: " + number);
    }
}

class HexNum extends Num {
    public HexNum(int number) {
    super(number);
    }
    @Override
    public void showNum () {
        System.out.println("Hexadecimal Value: " + Integer.toHexString(number));
    }
}

class OctNum extends Num {
    public OctNum(int number) {
        super(number);
    }
    @Override
    public void showNum() {
        System.out.println("Octal Value: " + Integer.toOctalString(number));
    }
}

public class Twelve {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int userInput = scanner.nextInt();
        Num baseNum = new Num(userInput);
        HexNum hexNum = new HexNum(userInput);
        OctNum octNum = new OctNum(userInput);
        System.out.println("\nBase Num Information:");
        baseNum.showNum();
        System.out.println("\nHex Num Information:");
        hexNum.showNum();
        System.out.println("\nOct Num Information:");
        octNum.showNum();
    }
}