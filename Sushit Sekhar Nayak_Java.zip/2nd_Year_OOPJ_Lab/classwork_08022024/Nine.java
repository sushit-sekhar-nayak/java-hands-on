// In the earlier program, create a second derived class Office that inherits Building and stores the number of telephones and tables. Now demonstrate the working of all three classes.

import java.util.*;

class Building {
    private int numFloors;
    private int numRooms;
    private double totalFootage;

    public Building(int numFloors, int numRooms, double totalFootage) {
        this.numFloors = numFloors;
        this.numRooms = numRooms;
        this.totalFootage = totalFootage;
    }

    public void displayInfo() {
        System.out.println("Number of Floors: " + numFloors);
        System.out.println("Number of Rooms: " + numRooms);
        System.out.println("Total Footage: " + totalFootage + " sq. ft");
    }
}

class House extends Building {
    private int numBedrooms;
    private int numBathrooms;

    public House(int numFloors, int numRooms, double totalFootage, int numBedrooms, int numBathrooms) {
        super(numFloors, numRooms, totalFootage);
        this.numBedrooms = numBedrooms;
        this.numBathrooms = numBathrooms;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Bedrooms: " + numBedrooms);
        System.out.println("Number of Bathrooms: " + numBathrooms);
    }
}

class Office extends Building {
    private int numTelephones;
    private int numTables;

    public Office(int numFloors, int numRooms, double totalFootage, int numTelephones, int numTables) {
        super(numFloors, numRooms, totalFootage);
        this.numTelephones = numTelephones;
        this.numTables = numTables;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Telephones: " + numTelephones);
        System.out.println("Number of Tables: " + numTables);
    }
}

public class Nine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input for Building
        System.out.println("Enter Building Details:");
        System.out.print("Enter Number of Floors: ");
        int numFloorsBuilding = scanner.nextInt();
        System.out.print("Enter Number of Rooms: ");
        int numRoomsBuilding = scanner.nextInt();
        System.out.print("Enter Total Footage: ");
        double totalFootageBuilding = scanner.nextDouble();
        Building building = new Building(numFloorsBuilding, numRoomsBuilding, totalFootageBuilding);

        // Input for House
        System.out.println("\nEnter House Details:");
        System.out.print("Enter Number of Bedrooms: ");
        int numBedroomsHouse = scanner.nextInt();
        System.out.print("Enter Number of Bathrooms: ");
        int numBathroomsHouse = scanner.nextInt();
        System.out.print("Enter Number of Floors: ");
        int numFloorsHouse = scanner.nextInt();
        System.out.print("Enter Number of Rooms: ");
        int numRoomsHouse = scanner.nextInt();
        System.out.print("Enter Total Footage: ");
        double totalFootageHouse = scanner.nextDouble();
        House house = new House(numFloorsHouse, numRoomsHouse, totalFootageHouse, numBedroomsHouse, numBathroomsHouse);

        // Input for Office
        System.out.println("\nEnter Office Details:");
        System.out.print("Enter Number of Telephones: ");
        int numTelephonesOffice = scanner.nextInt();
        System.out.print("Enter Number of Tables: ");
        int numTablesOffice = scanner.nextInt();
        System.out.print("Enter Number of Floors: ");
        int numFloorsOffice = scanner.nextInt();
        System.out.print("Enter Number of Rooms: ");
        int numRoomsOffice = scanner.nextInt();
        System.out.print("Enter Total Footage: ");
        double totalFootageOffice = scanner.nextDouble();
        Office office = new Office(numFloorsOffice, numRoomsOffice, totalFootageOffice, numTelephonesOffice, numTablesOffice);

        // Displaying Information
        System.out.println("\nBuilding Information:");
        building.displayInfo();
        System.out.println("\nHouse Information:");
        house.displayInfo();
        System.out.println("\nOffice Information:");
        office.displayInfo();

        scanner.close();
    }
}