// Write a program in Java to take first name and last name from user and print both in one line as last name followed by first name

import java.util.*;

public class five {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the First Name : ");
        String a = input.nextLine();
        System.out.print ("Enter the Second Name : ");
        String b = input.nextLine();
        System.out.print ("The Output is : " + b + " " + a);
    }
}