// Accept 10 numbers from command line and check how many of them are even and how many are odd.

import java.util.*;

public class seven {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        int arr[] = new int[50];
        System.out.println ("Enter the numbers below-");
        for (int i=0; i<10; i++) {
            arr[i] = input.nextInt();
        }
        int even=0, odd=0;
        for (int i=0; i<10; i++) {
            if (arr[i]%2 == 0)
                even++;
            else
                odd++;
        }
        System.out.println ("Even: " + even);
        System.out.print ("Odd : " + odd);
    }
}