// Write a program to print the week day for the given day no. of the current month using switch case statement

import java.util.*;

public class three {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the Day Number : ");
        int a = input.nextInt();
        if (a<1 && a>31) {
            System.out.print ("Error!");
            return;
        }
        int weekday = a%7 + 1;
        switch (weekday) {
            case 1:
                System.out.print ("Sunday");
                break;
            case 2:
                System.out.print ("Monday");
                break;
            case 3:
                System.out.print ("Tuesday");
                break;
            case 4:
                System.out.print ("Wednesday");
                break;
            case 5:
                System.out.print ("Thursday");
                break;
            case 6:
                System.out.print ("Friday");
                break;
            case 7:
                System.out.print ("Saturday");     
                break;
            default:
                System.out.print ("Error!");
        }
    }
}