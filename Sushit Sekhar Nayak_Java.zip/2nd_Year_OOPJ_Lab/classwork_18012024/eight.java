// Program to sort the user entered list of numbers of any size

import java.util.*;

public class eight {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        int arr[] = new int[50];
        System.out.print ("How many numbers you want to insert : ");
        int n = input.nextInt();
        System.out.println ("Enter the numbers below-");
        for (int i=0; i<n; i++) {
            arr[i] = input.nextInt();
        }
        System.out.print ("The list of numbers before sorting :");
        for (int i=0; i<n; i++) {
            System.out.print (" " + arr[i]);
        }
        System.out.println();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        System.out.print ("The list of numbers after sorting :");
        for (int i=0; i<n; i++) {
            System.out.print (" " + arr[i]);
        }
    }
}