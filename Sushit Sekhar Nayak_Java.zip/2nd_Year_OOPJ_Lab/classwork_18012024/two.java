// Write a program to print the corresponding grade for the given mark using if..else statement in Java

import java.util.*;

public class two {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the Marks : ");
        int a = input.nextInt();
        if (a>89 && a<101)
            System.out.print ("You got O Grade.");
        else if (a>79 && a<90)
            System.out.print ("You got E Grade.");
        else if (a>69 && a<80)
            System.out.print ("You got A Grade.");
        else if (a>59 && a<70)
            System.out.print ("You got B Grade.");
        else if (a>=0 && a<60)
            System.out.print ("You got C Grade.");
        else {
            System.out.print ("Enter Correct Marks!");
        }
    }
}