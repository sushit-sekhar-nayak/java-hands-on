// Accept 10 numbers from command line and check how many of them are even and how many are odd.

public class sevenCMD {
    public static void main (String args[]) {
        if (args.length != 10) {
            System.out.print ("Enter exactly 10 numbers!");
            return;
        }
        int arr[] = new int[10];
        for (int i=0; i<args.length; i++) {
            arr[i] = Integer.parseInt(args[i]);
        }
        int even=0, odd=0;
        for (int i=0; i<args.length; i++) {
            if (arr[i]%2 == 0)
                even++;
            else
                odd++;
        }
        System.out.println ("Even Count : " + even);
        System.out.print ("Odd Count : " + odd);
    }
}