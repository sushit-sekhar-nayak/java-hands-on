// Write a program to print your name, roll no, section and branch in separate lines.

import java.util.*;

public class one {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter your Name : ");
        String s = input.nextLine();
        System.out.print ("Enter your Roll no : ");
        int a = input.nextInt();
        input.nextLine();
        System.out.print ("Enter your Section : ");
        int b = input.nextInt();
        input.nextLine();
        System.out.print ("Enter your Branch : ");
        String q = input.nextLine();
        System.out.println ("Your details are-");
        System.out.println ("NAME: " + s);
        System.out.println ("ROLL NO: " + a);
        System.out.println ("SECTION: " + b);
        System.out.print ("BRANCH: " + q);

        input.close();
    }
}