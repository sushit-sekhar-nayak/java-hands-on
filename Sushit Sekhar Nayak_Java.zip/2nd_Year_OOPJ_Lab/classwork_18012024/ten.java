// Find the no. of occurrence of each element in a user entered list of nos.

import java.util.*;

public class ten {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        int arr[] = new int[50];
        System.out.print ("How many numbers you want to insert : ");
        int n = input.nextInt();
        System.out.println ("Enter " + n + " numbers below-");
        for (int i=0; i<n; i++) {
            arr[i] = input.nextInt();
        }
        System.out.print ("The List of numbers is :");
        for (int i=0; i<n; i++) {
            System.out.print (" " + arr[i]);
        }
        System.out.println();
        for (int i = 0; i < n; i++) {
            if (arr[i] != -1) {
                int count = 1;
                for (int j = i + 1; j < n; j++) {
                    if (arr[i] == arr[j]) {
                        count++;
                        arr[j] = -1;
                    }
                }
                System.out.println("Occurrence of " + arr[i] + " is: " + count);
            }
        }
    }
}