// Find sum of each diagonal (left & right) elements separately of a user entered 3 X 3 matrix in Java.

import java.util.*;

public class eleven {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        int mat[][] = new int[50][50];
        System.out.print ("Enter the size of Square Matrix : ");
        int n = input.nextInt();
        System.out.println ("Enter the numbers below-");
        for (int i=0; i<n; i++) {
            for (int j=0; j<n; j++) {
                System.out.print ("Enter the element at " + (i+1) + (j+1) + " : ");
                mat[i][j] = input.nextInt();
            }
        }
        int left=0, right=0;
        System.out.println ("The " + n + "x" + n + " matrix is-");
        for (int i=0; i<n; i++) {
            for (int j=0; j<n; j++) {
                System.out.print (mat[i][j] + " ");
            }
            left += mat[i][i];
            right += mat[i][n-i-1];
            System.out.println();
        }
        System.out.println ("Summation of Left : " + left);
        System.out.print ("Summation of Right : " + right);
    }
}