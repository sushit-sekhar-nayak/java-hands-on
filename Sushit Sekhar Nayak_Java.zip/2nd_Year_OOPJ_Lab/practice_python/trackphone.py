import phonenumbers
from phonenumbers import geocoder
phone_number1 = phonenumbers.parse("+918144052635")
phone_number2 = phonenumbers.parse("+917978797330")
phone_number3 = phonenumbers.parse("+918249290400")
phone_number4 = phonenumbers.parse("+919853040666")
phone_number5 = phonenumbers.parse("+916370743145")
phone_number6 = phonenumbers.parse("+919237101384")

print("Phone Numbers Location-")
print(geocoder.description_for_number(phone_number1, "en"))
print(geocoder.description_for_number(phone_number2, "en"))
print(geocoder.description_for_number(phone_number3, "en"))
print(geocoder.description_for_number(phone_number4, "en"))
print(geocoder.description_for_number(phone_number5, "en"))
print(geocoder.description_for_number(phone_number6, "en"))