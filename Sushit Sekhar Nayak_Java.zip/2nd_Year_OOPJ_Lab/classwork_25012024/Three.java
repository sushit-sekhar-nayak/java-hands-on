// Write a program in java to input and display the details of n number of students having roll, name and cgpa as data members. Also display the name of the student having lowest cgpa.

import java.util.*;

class Student {
    int roll;
    String name;
    double cgpa;

    Student(int r, String n, double c) {
        roll = r;
        name = n;
        cgpa = c;
    }
}

public class Three {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of students: ");
        int n = input.nextInt();

        Student[] students = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for student " + (i + 1) + ":");
            System.out.print("Roll Number: ");
            int roll = input.nextInt();
            System.out.print("Name: ");
            String name = input.next();
            System.out.print("CGPA: ");
            double cgpa = input.nextDouble();

            students[i] = new Student(roll, name, cgpa);
        }

        System.out.println("\nDetails of Students:");
        for (int i = 0; i < n; i++) {
            System.out.println("Student " + (i + 1) + ": Roll-" + students[i].roll
                    + ", Name-" + students[i].name + ", CGPA-" + students[i].cgpa);
        }

        int lowestIndex = 0;
        for (int i = 1; i < n; i++) {
            if (students[i].cgpa < students[lowestIndex].cgpa) {
                lowestIndex = i;
            }
        }

        System.out.println("\nStudent with the lowest CGPA: " + students[lowestIndex].name);
    }
}