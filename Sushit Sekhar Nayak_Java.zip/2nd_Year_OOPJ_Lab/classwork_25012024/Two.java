import java.util.*;

class Rectangle {
    int length;
    int breadth;

    Rectangle(int l, int b) {
        length = l;
        breadth = b;
    }

    int perimeterShow() {
        return 2 * (length + breadth);
    }

    int areaShow() {
        return length * breadth;
    }

    void input() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Length : ");
        this.length = input.nextInt();
        System.out.print("Enter the Breadth : ");
        this.breadth = input.nextInt();
    }

    void display() {
        System.out.println("The Perimeter is : " + perimeterShow());
        System.out.print("The Area is : " + areaShow());
    }
}

public class Two {
    public static void main(String args[]) {
        Rectangle obj1 = new Rectangle(0, 0);
        obj1.input();
        int perimeter = obj1.perimeterShow();
        int area = obj1.areaShow();
        obj1.display();
    }
}