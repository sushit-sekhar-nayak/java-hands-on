import java.util.*;

// TAKE A NO. AND CHECK WHETHER THE NO. IS PRIME OR NOT

public class three {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the number you want to check : ");
        int a = input.nextInt();
        int count=0;
        for (int i=1; i<=a; i++) {
            if (a%i == 0) {
                count++;
            }
        }
        if (count == 2) {
            System.out.print ("The number " + a + " is Prime.");
        }
        else {
            System.out.print ("The number " + a + " is not Prime.");
        }
    }
}