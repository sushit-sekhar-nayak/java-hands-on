#include <stdio.h>

int main () {
    printf ("%d", printf("Kiit"));
    return 0;
}