import java.util.*;

// TAKE A NO. AND CHECK WHETHER THE NO. IS PALINDROME OR NOT

public class five {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the number you want to check : ");
        int a = input.nextInt();
        int rev=0, num = a;
        while (a != 0) {
            rev = rev*10 + (a%10);
            a = a/10;
        }
        if (num == rev) {
            System.out.print ("The number " + num + " is Palindrome.");
        }
        else {
            System.out.print ("The number " + num + " is not Palindrome.");
        }
    }
}