import java.util.*;

// TAKE TWO VARIABLE AND FIND THEIR ADDITION, MULTIPLICATION, DIVISION, SUBTRACTION

public class one {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the first number : ");
        int a = input.nextInt();
        System.out.print ("Enter the second number : ");
        int b = input.nextInt();
        System.out.println ("ADDITION-");
        System.out.println ("a + b = " + (a+b));
        System.out.println ("MULTIPLICATION-");
        System.out.println ("a * b = " + (a*b));
        System.out.println ("DIVISTION-");
        System.out.println ("a / b = " + (a/b));
        System.out.println ("SUBTRACTION-");
        System.out.print ("a - b = " + (a-b));
    }
}