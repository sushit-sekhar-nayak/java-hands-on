import java.util.*;

// TAKE TWO NO. AND CHECK WHETHER THEY ARE CO-PRIME OR NOT

public class four {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the first number : ");
        int a = input.nextInt();
        System.out.print ("Enter the second number : ");
        int b = input.nextInt();
        int largest;
        if (a>b)
            largest = a;
        else
            largest = b;
        int commonFactor = 0;
        for (int i=1; i<=largest; i++) {
            if (a%i==0 && b%i==0) {
                commonFactor = i;
            }
        }
        if (commonFactor == 1)
            System.out.print ("The numbers " + a + " and " + b + " are Co-Prime.");
        else
            System.out.print ("The numbers " + a + " and " + b + " are not Co-Prime.");

    }
}