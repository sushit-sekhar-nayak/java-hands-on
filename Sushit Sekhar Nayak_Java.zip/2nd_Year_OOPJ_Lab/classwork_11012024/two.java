import java.util.*;

// TAKE A NO. AND CHECK WHETHER THE NO. IS EVEN OR NOT

public class two {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the number you want to check : ");
        int a = input.nextInt();
        if (a%2 == 0) {
            System.out.print ("The number " + a + " is Even.");
        }
        else {
            System.out.print ("The number " + a + " is Odd.");
        }
    }
}