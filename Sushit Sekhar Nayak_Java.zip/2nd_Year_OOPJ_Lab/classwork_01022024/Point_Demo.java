import java.util.*;

class Point {
    int x;
    int y;
    int z;
    Point () {
        x = 0;
        y = 0;
        z = 0;
    }
    Point (int a, int b, int c) {
        x = a;
        y = b;
        z = c;
    }
    Point (Point obj) {
        x = obj.x;
        y = obj.y;
        z = obj.z;
    }
    float find_distance () {
        return (float) Math.sqrt(x*x+y*y+z*z);
    }
    float find_distance (int x1, int y1, int z1) {
        return (float) Math.sqrt(Math.pow(x-x1, 2)+Math.pow(y-y1, 2)+Math.pow(z-z1, 2));
    }
    float find_distance (Point P1) {
        return (float) Math.sqrt(Math.pow(x-P1.x, 2)+Math.pow(y-P1.y, 2)+Math.pow(z-P1.z, 2));
    }
    boolean is_Equal (Point P1) {
        if (x==P1.x && y==P1.y && z==P1.z)
            return true;
        else
            return false;
    }
    void show () {
        System.out.println ("The Point is : " + x + " " + y + " " + z);
    }
}

public class Point_Demo {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter X-Coordinate : ");
        int x = input.nextInt();
        System.out.print ("Enter Y-Coordinate : ");
        int y = input.nextInt();
        System.out.print ("Enter Z-Coordinate : ");
        int z = input.nextInt();
        Point p1 = new Point();
        Point p2 = new Point(x, y, z);
        Point p3 = new Point(p2);
        System.out.println("Point Details-");
        p1.show();
        p2.show();
        p3.show();
        System.out.print("Enter x1 coordinate for distance calculation : ");
        int x1 = input.nextInt();
        System.out.print("Enter y1 coordinate for distance calculation : ");
        int y1 = input.nextInt();
        System.out.print("Enter z1 coordinate for distance calculation : ");
        int z1 = input.nextInt();
        System.out.println("Distance from origin for p2 : " + p2.find_distance());
        System.out.println("Distance between p1 and (x1, y1, z1): " + p1.find_distance(x1, y1, z1));
        System.out.println("Distance between p1 and p2: " + p1.find_distance(p2));
        System.out.println("Are p1 and p2 equal? " + p1.is_Equal(p2));
        System.out.println("Are p2 and p3 equal? " + p2.is_Equal(p3));
    }
}