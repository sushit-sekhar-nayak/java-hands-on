// Write a program in java using constructor overloading concept to calculate the area of a rectangle having data member as length and breadth. Use default constructor to initialize the value of the data member to zero and parameterized constructor to initialize the value of data member according to the user input.

import java.util.*;

class Rectangle {
    int length;
    int breadth;
    Rectangle () {
        length = 0;
        breadth = 0;
    }
    Rectangle (int l, int b) {
        length = l;
        breadth = b;
    }
    void displayArea () {
        System.out.print ("The Area of Rectangle is : " + length*breadth);
    }
}

public class Six {
    public static void main (String args[]) {
        Scanner input = new Scanner(System.in);
        System.out.print ("Enter the length : ");
        int length = input.nextInt();
        System.out.print ("Enter the breadth : ");
        int breadth = input.nextInt();
        Rectangle obj1 = new Rectangle(length, breadth);
        obj1.displayArea();
    }
}