import java.util.*;

class Number {
    int value;
    boolean is_Even () {
        if (value%2 == 0)
            return true;
        else
            return false;
    }
    boolean is_Prime () {
        int factors=0;
        for (int i=1; i<=value; i++) {
            if (value%i == 0)
                factors++;
        }
        if (factors == 2)
            return true;
        else
            return false;
    }
    boolean is_Perfect () {
        int sum = 0;
        for (int i=1; i<value; i++) {
            if (value%i == 0) {
                sum += i;
            }
        }
        if (sum == value)
            return true;
        else
            return false;
    }
    int fin_factorial (int v) {
        if (v==1 || v==0)
            return 1;
        else
            return v*fin_factorial(v-1);
    }
}

public class Number_Demo {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        Number obj1 = new Number();
        System.out.print ("Enter the Number : ");
        obj1.value = input.nextInt();
        if (obj1.is_Even() == true)
            System.out.println ("The Entered Number is Even.");
        else
            System.out.println ("The Entered Number is Not Even.");
        if (obj1.is_Prime() == true)
            System.out.println ("The Entered Number is Prime.");
        else
            System.out.println ("The Entered Number is Not Prime.");
        if (obj1.is_Perfect() == true)
            System.out.println ("The Entered Number is Perfect.");
        else
            System.out.println ("The Entered Number is Not Perfect.");
        System.out.print("The Factorial of " + obj1.value + " is : " + obj1.fin_factorial(obj1.value));
    }
}