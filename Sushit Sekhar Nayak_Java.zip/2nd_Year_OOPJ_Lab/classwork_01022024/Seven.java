// Write a program in java to input the details of a student having roll, name, full_mark and secured_mark as data members using constructor, then calculate the CGPA and display the details of student with CGPA.

import java.util.*;

class Student {
    int roll;
    String name;
    int full_marks;
    int secured_marks;
    
    Scanner input = new Scanner (System.in);
    

    void input () {
        System.out.print ("Enter the Roll Number : ");
        roll = input.nextInt();
        input.nextLine();
        System.out.print ("Enter your Name : ");
        name = input.nextLine();
        System.out.print ("Enter Full Marks : ");
        full_marks = input.nextInt();
        System.out.print ("Enter your Secured Marks : ");
        secured_marks = input.nextInt();
    }
    
    void display () {
        double cgpa = ((double)secured_marks/full_marks)*10;
        System.out.println ("Your Details are-");
        System.out.println ("ROLL: " + roll);
        System.out.println ("NAME: " + name);
        System.out.println ("CGPA: " + cgpa);
    }
}

public class Seven {
    public static void main (String args[]) {
        System.out.println ("Enter the Details below-");
        Student s1 = new Student ();
        s1.input();
        s1.display();
    }
}