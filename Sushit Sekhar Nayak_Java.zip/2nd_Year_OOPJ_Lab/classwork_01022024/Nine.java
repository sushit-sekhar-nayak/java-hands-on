// A plastic manufacturer sells plastic in different shapes like 2D sheet and 3D box. The cost of sheet is Rs 40/ per square ft. and the cost of box is Rs 60/ per cubic ft. Implement it in Java to calculate the cost of plastic as per the dimensions given by the user where 3D inherits from 2-D

import java.util.*;

class TwoDimensional {
    int length;
    int breadth;
    void input () {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the Length of Sheet : ");
        length = input.nextInt();
        System.out.print ("Enter the Breadth of Sheet : ");
        breadth = input.nextInt();
    }
    void CostCalculation () {
        System.out.print ("The Cost is : " + (length*breadth*40));
    }
}

class ThreeDimensional extends TwoDimensional {
    int height;
    void input () {
        super.input();
        Scanner input = new Scanner (System.in);
        System.out.print("Enter the Height of the Box : ");
        height = input.nextInt();
    }
    void CostCalculation () {
        System.out.print ("The Cost is : " + (length*breadth*height*60));
    }
}

public class Nine {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.println ("Choose a Shape-");
        System.out.println ("1. 2-D Sheet");
        System.out.println ("2. 3-D Box");
        System.out.print ("Enter yout Choice : ");
        int choice = input.nextInt();

        switch (choice) {
            case 1:
                TwoDimensional obj1 = new TwoDimensional();
                obj1.input();
                obj1.CostCalculation();
                break;
            case 2:
                ThreeDimensional obj2 = new ThreeDimensional();
                obj2.input();
                obj2.CostCalculation();
                break;
            default:
                System.out.print ("Enter Correct Choice!");
        }
    }
}