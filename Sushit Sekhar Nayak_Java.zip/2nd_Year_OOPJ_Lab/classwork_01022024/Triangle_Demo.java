import java.util.*;

class Triangle {
    float a;
    float b;
    float c;
    void set_Dim () {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the First Side of Triangle : ");
        a = input.nextFloat();
        System.out.print ("Enter the Second Side of Triangle : ");
        b = input.nextFloat();
        System.out.print ("Enter the Third Side of Triangle : ");
        c = input.nextFloat();
    }
    boolean is_Triangle () {
        if ((a+b)>c && (b+c)>a && (c+a)>b) {
            return true;
        }
        else {
            return false;
        }
    }
    float find_area () {
        float s = (a+b+c)/2;
        float area = (float) Math.sqrt(s*(s-a)*(s-b)*(s-c));
        return area;
    }
    float find_perimeter () {
        float perimeter = a+b+c;
        return perimeter;
    }
    void show () {
        System.out.println ("The Sides of Triangle are : " + a + " " + b + " " + c);
        System.out.println ("The Area of the Triangle is : " + find_area());
        System.out.println ("The Perimeter of the Triangle is : " + find_perimeter());
    }
}

public class Triangle_Demo {
    public static void main (String args[]) {
        Triangle obj1 = new Triangle();
        obj1.set_Dim();
        if (obj1.is_Triangle() == true) {
            System.out.println ("Triangle is Possible.");
        }
        else {
            System.out.print ("Triangle is Not Possible!");
            return;
        }
        obj1.show();
    }
}