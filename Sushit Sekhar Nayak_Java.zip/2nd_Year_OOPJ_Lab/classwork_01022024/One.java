public class One {
    public static void main (String args[]) {
        if (args.length != 3) {
            System.out.println ("Enter 3 numbers only!");
        }
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        int c = Integer.parseInt(args[2]);
        if (a>b && a>c)
            System.out.print ("The number " + a + " is Largest.");
        else if (b>a && b>c)
            System.out.print ("The number " + b + " is Largest.");
        else if (c>a && c>b)
            System.out.print ("The number " + c + " is Largest.");
        else if (a==b && a>c)
            System.out.print ("The numbers " + a + " and " + b + " are Largest.");
        else if (b==c && b>a)
            System.out.print ("The numbers " + b + " and " + c + " are Largest.");
        else if (c==a && c>b)
            System.out.print ("The numbers " + c + " and " + a + " are Largest.");
        else
            System.out.print ("All are Equal which is " + a);
    }
}