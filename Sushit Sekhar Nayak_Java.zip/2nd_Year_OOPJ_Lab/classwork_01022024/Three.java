// Write a class file – box with three data members(length, width, height) and a method volume() . Also implement the application class Demo where an object of the box class is created with user entered dimensions and volume is printed.

import java.util.*;

class Box {
    int length;
    int width;
    int height;
    Box (int l, int w, int h) {
        length = l;
        width = w;
        height = h;
    }
    void volumeShow () {
        System.out.print ("The Volume is : " + length*width*height);
    }
}

public class Three {
    public static void main (String args[]) {
        Scanner input = new Scanner(System.in);
        System.out.print ("Enter the Length : ");
        int length = input.nextInt();
        System.out.print ("Enter the Width : ");
        int width = input.nextInt();
        System.out.print ("Enter the Height : ");
        int height = input.nextInt();
        Box obj1 = new Box(length, width, height);
        obj1.volumeShow();
    }
}