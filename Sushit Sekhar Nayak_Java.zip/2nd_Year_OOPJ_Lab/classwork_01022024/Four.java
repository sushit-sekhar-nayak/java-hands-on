// Write a program to overload subtract method with various parameters in a class in Java. Write the driver class to use the different subtract methods using object.

import java.util.Scanner;

class Subtraction {
    // Two integers
    int subtract(int a, int b) {
        return a - b;
    }

    // Two doubles
    double subtract(double a, double b) {
        return a - b;
    }
}

public class Four {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        Subtraction subtractor = new Subtraction();

        System.out.print("Enter two integers to subtract: ");
        int int1 = input.nextInt();
        int int2 = input.nextInt();
        System.out.println("Result of integer subtraction: " + subtractor.subtract(int1, int2));

        System.out.print("Enter two doubles to subtract: ");
        double double1 = input.nextDouble();
        double double2 = input.nextDouble();
        System.out.println("Result of double subtraction: " + subtractor.subtract(double1, double2));
    }
}