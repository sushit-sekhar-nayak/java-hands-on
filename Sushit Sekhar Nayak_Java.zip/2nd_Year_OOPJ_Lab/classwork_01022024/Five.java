// Write a program which will overload the area () method and display the area of a circle, triangle and square as per user choice and user entered dimensions.

import java.util.*;

class Shape {
    int radius;
    int base;
    int height;
    int side;

    double Area (double radius) {
        return (3.14*radius*radius);
    }

    double Area (double base, double height) {
        return (0.5*base*height);
    }

    int Area (int side) {
        return (side*side);
    }
}

public class Five {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        Shape shape = new Shape();

        System.out.println("Choose a shape to find its area:");
        System.out.println("1. Circle");
        System.out.println("2. Triangle");
        System.out.println("3. Square");
        System.out.print("Enter your choice: ");
        int choice = input.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter radius of the circle: ");
                double radius = input.nextDouble();
                System.out.println("Area of the circle: " + shape.Area(radius));
                break;
            case 2:
                System.out.print("Enter base of the triangle: ");
                double base = input.nextDouble();
                System.out.print("Enter height of the triangle: ");
                double height = input.nextDouble();
                System.out.println("Area of the triangle: " + shape.Area(base, height));
                break;
            case 3:
                System.out.print("Enter side of the square: ");
                int side = input.nextInt();
                System.out.println("Area of the square: " + shape.Area(side));
                break;
            default:
                System.out.println("Invalid choice!");
        }
    }
}