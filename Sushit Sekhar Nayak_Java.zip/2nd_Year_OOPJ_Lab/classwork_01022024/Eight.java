// Write a program in Java to create a class MyVolume with required data members and find the volume of cube, cuboid and sphere using constructor overloading.

import java.util.*;

class MyVolume {
    int cube_side;
    int cuboid_length;
    int cuboid_breadth;
    int cuboid_height;
    int sphere_radius;
    MyVolume (int side) {
        cube_side = side;
        System.out.print ("The Volume of Cube is : " + (cube_side*cube_side*cube_side));
    }
    MyVolume (int length, int breadth, int height) {
        cuboid_length = length;
        cuboid_breadth = breadth;
        cuboid_height = height;
        System.out.print ("The Volume of Cuboid is : " + (cuboid_length*cuboid_breadth*cuboid_height));
    }
    MyVolume (double radius) {
        double volume = (4.0/3.0)*Math.PI*radius*radius*radius;
        System.out.print ("The Volume of Sphere is : " + volume);
    }
}

public class Eight {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.println ("Which Shape :");
        System.out.println ("1. Cube");
        System.out.println ("2. Cuboid");
        System.out.println ("3. Sphere");
        System.out.print ("Enter Your Choice : ");
        int choice = input.nextInt();
        switch (choice) {
            case 1:
                System.out.print ("Enter the Side : ");
                int side = input.nextInt();
                MyVolume cube = new MyVolume (side);
                break;
            case 2:
                System.out.print ("Enter the Length : ");
                int length = input.nextInt();
                System.out.print ("Enter the Breadth : ");
                int breadth = input.nextInt();
                System.out.print ("Enter the Height : ");
                int height = input.nextInt();
                MyVolume cuboid = new MyVolume (length, breadth, height);
                break;
            case 3:
                System.out.print ("Enter the Radius : ");
                double radius = input.nextDouble();
                MyVolume sphere = new MyVolume (radius);
                break;
            default :
                System.out.print ("Enter Correct Choice!");
        }
    }
}