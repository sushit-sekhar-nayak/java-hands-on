// Find the largest among 3 user entered nos. at the command prompt using Java

import java.util.*;

public class six {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the first number : ");
        int a = input.nextInt();
        System.out.print ("Enter the second number : ");
        int b = input.nextInt();
        System.out.print ("Enter the third number : ");
        int c = input.nextInt();
        if (a>b && a>c)
            System.out.print ("The number " + a + " is Largest.");
        else if (b>a && b>c)
            System.out.print ("The number " + b + " is Largest.");
        else if (c>a && c>b)
            System.out.print ("The number " + c + " is Largest.");
        else if (a==b && a>c)
            System.out.print ("The numbers " + a + " and " + b + " are Largest.");
        else if (b==c && b>a)
            System.out.print ("The numbers " + b + " and " + c + " are Largest.");
        else if (c==a && c>b)
            System.out.print ("The numbers " + c + " and " + a + " are Largest.");
    }
}