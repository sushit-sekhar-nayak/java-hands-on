// Write a program to print "Good morning" and "Welcome" continuously on the screen in Java using threads.

public class Eleven {
    public static void main(String[] args) {
        Thread morningThread = new Thread(new MorningPrinter());
        Thread welcomeThread = new Thread(new WelcomePrinter());

        morningThread.start();
        welcomeThread.start();
    }

    static class MorningPrinter implements Runnable {
        @Override
        public void run() {
            while (true) {
                System.out.println("Good morning");
                try {
                    Thread.sleep(2000);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static class WelcomePrinter implements Runnable {
        @Override
        public void run() {
            while (true) {
                System.out.println("Welcome");
                try {
                    Thread.sleep(1500);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}