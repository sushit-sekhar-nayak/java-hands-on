// Read two String user input and check if first contains second.

import java.util.*;

public class One {
    public static void main (String args[]) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter First String : ");
        String a = input.nextLine();
        System.out.print ("Enter Second String : ");
        String b = input.nextLine();
        if (a.contains(b)) {
            System.out.print ("Yes, First one contains the Second.");
        }
        else {
            System.out.print ("No, First oone does not contain the Second.");
        }
    }
}