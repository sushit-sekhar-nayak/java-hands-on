// How to check if a String is Palindrome?

public class Six {
    public static void main(String[] args) {
        String str = "sus";
        System.out.println("Is the string a palindrome? " + isPalindrome(str));
    }

    private static boolean isPalindrome(String str) {
        int i = 0, j = str.length() - 1;

        while (i < j) {
            if (str.charAt(i) != str.charAt(j))
                return false;
            i++;
            j--;
        }
        return true;
    }
}