// How to remove all occurrences of a given character from input String?

public class Five {
    public static void main(String[] args) {
        String input = "hello world";
        char charToRemove = 'o';
        
        String result = removeCharacter(input, charToRemove);
        System.out.println("Result: " + result);
    }

    public static String removeCharacter(String str, char ch) {
        return str.replace(String.valueOf(ch), "");
    }
}