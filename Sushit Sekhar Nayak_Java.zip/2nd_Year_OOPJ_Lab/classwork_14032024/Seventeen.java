// Write a Java program to create a producer-consumer scenario using the wait() and notify() methods for thread synchronization.

import java.util.Scanner;
class ProducerConsumer {
    private final int[] buffer;
    private int size;
    private int capacity;
    private int front;
    private int rear;
    public ProducerConsumer(int capacity) {
        this.capacity = capacity;
        buffer = new int[capacity];
        size = 0;
        front = 0;
        rear = 0;
    }
    public synchronized void produce(int item) throws InterruptedException {
        while (size == capacity) {
            wait(); // Wait if buffer is full
        }
        System.out.println("Producer produced: " + item);
        buffer[rear] = item;
        rear = (rear + 1) % capacity;
        size++;
        notify();
        Thread.sleep(1000);
    }
    public synchronized void consume() throws InterruptedException {
        while (size == 0) {
            wait();
        }
        int consumedValue = buffer[front];
        front = (front + 1) % capacity;
        size--;
        System.out.println("Consumer consumed: " + consumedValue);
        notify();
        Thread.sleep(1000);
    }
}
public class Seventeen {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter buffer capacity: ");
        int capacity = scanner.nextInt();
        ProducerConsumer pc = new ProducerConsumer(capacity);
        System.out.print("Enter number of items to produce: ");
        int numItemsToProduce = scanner.nextInt();
        Thread producerThread = new Thread(() -> {
            try {
                for (int i = 0; i < numItemsToProduce; i++) {
                    pc.produce(i);
                }
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        System.out.print("Enter number of items to consume: ");
        int numItemsToConsume = scanner.nextInt();
        Thread consumerThread = new Thread(() -> {
            try {
                for (int i = 0; i < numItemsToConsume; i++) {
                    pc.consume();
                }
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        producerThread.start();
        consumerThread.start();
    }
}