// Write a Java program to create and start multiple threads that increment a shared counter variable concurrently.

public class Sixteen {
    private static int counter = 0;

    public static void main(String[] args) {
        int numThreads = 5;
        Thread[] threads = new Thread[numThreads];

        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(new CounterIncrementer());
            threads[i].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Final Counter Value: " + counter);
    }

    static class CounterIncrementer implements Runnable {
        @Override
        public void run() {
            for (int i = 0; i < 1000; i++) {
                incrementCounter();
            }
        }

        private void incrementCounter() {
            synchronized (Sixteen.class) {
                counter++;
            }
        }
    }
}