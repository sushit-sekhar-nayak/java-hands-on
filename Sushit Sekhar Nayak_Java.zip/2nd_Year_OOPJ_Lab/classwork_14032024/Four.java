// Provide two ways to check if a String contains only digit.

public class Four {
    public static void main(String[] args) {
        String str = "12345";
        boolean result1 = containsOnlyDigits1(str);
        System.out.println("Contains only digits: " + result1);
        boolean result2 = containsOnlyDigits2(str);
        System.out.println("Contains only digits: " + result2);
    }

    public static boolean containsOnlyDigits1(String str) {
        return str.matches("[0-9]+");
    }

    public static boolean containsOnlyDigits2(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }
}