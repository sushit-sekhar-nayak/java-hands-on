// Add a step method in the welcome thread of question 1 to delay its execution for 200ms.

class GoodMorningThread extends Thread {
    public void run() {
        while (true) {
            System.out.println("Good morning");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class WelcomeThread extends Thread {
    public void run() {
        while (true) {
            System.out.println("Welcome");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void step() {
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class Twelve {
    public static void main(String[] args) {
        GoodMorningThread goodMorningThread = new GoodMorningThread();
        WelcomeThread welcomeThread = new WelcomeThread();
        goodMorningThread.start();
        welcomeThread.start();
        welcomeThread.step();
    }
}