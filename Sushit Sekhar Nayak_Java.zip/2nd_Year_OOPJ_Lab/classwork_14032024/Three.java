// Write a program to find out first non repeated character from input String.

public class Three {
    public static void main(String[] args) {
        String input = "AMAN RAj";
        char firstNR = findFirstNR(input);
        if (firstNR != '\0') {
            System.out.println("The first non-repeated character is: " + firstNR);
        } else {
            System.out.println("No non-repeated characters found in the input string.");
        }
    }

    public static char findFirstNR(String str) {
        for (int i = 0; i < str.length(); i++) {
            char currentChar = str.charAt(i);
            if (str.indexOf(currentChar) == str.lastIndexOf(currentChar)) {
                return currentChar;
            }
        }
        return '\0';
    }
}