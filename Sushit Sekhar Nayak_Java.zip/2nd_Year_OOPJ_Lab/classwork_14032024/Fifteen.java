// Write a code to  get the reference to the current thread in Java?

public class Fifteen {
    public static void main(String[] args) {
        Thread currentThread = Thread.currentThread();

        System.out.println("Current Thread: " + currentThread);
        System.out.println("Thread Name: " + currentThread.getName());
        System.out.println("Thread ID: " + currentThread.getId());
        System.out.println("Thread Priority: " + currentThread.getPriority());
        System.out.println("Thread State: " + currentThread.getState());
        System.out.println("Thread Group: " + currentThread.getThreadGroup());
    }
}