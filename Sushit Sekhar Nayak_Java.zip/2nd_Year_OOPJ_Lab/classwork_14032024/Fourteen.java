// Write a code to get the state of a given thread in Java.

public class Fourteen {
    public static void main(String[] args) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Running thread...");
            }
        });

        thread.start();

        Thread.State state = thread.getState();

        System.out.println("The state of the thread is: " + state);
    }
}