// Write code for display even number in and odd number separately from an an array using Thread.

class EvenThread extends Thread {
    private int[] array;

    public EvenThread(int[] array) {
        this.array = array;
    }

    public void run() {
        System.out.println("Even Numbers:");
        for (int num : array) {
            if (num % 2 == 0) {
                System.out.println(num);
            }
        }
    }
}

class OddThread extends Thread {
    private int[] array;

    public OddThread(int[] array) {
        this.array = array;
    }

    public void run() {
        System.out.println("Odd Numbers:");
        for (int num : array) {
            if (num % 2 != 0) {
                System.out.println(num);
            }
        }
    }
}

public class Eighteen {
    public static void main(String[] args) {
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        EvenThread evenThread = new EvenThread(numbers);
        OddThread oddThread = new OddThread(numbers);
        evenThread.start();
        oddThread.start();
    }
}