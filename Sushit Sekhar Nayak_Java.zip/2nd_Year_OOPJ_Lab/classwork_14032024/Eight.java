// How to print duplicate characters from the string?

import java.util.*;

public class Eight {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.print ("Enter the String : ");
        String str = input.nextLine();

        int[] charFreq = new int[256];

        for (char ch : str.toCharArray()) {
            charFreq[ch]++;
        }

        System.out.println("Duplicate characters in the string:");
        for (int i = 0; i < charFreq.length; i++) {
            if (charFreq[i] > 1) {
                System.out.println((char) i + " - " + charFreq[i] + " times");
            }
        }
    }
}