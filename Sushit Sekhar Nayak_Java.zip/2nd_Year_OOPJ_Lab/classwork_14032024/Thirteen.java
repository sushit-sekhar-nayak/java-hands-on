// Demonstrate gerPriority() and setPriority() methods in Java threads.

public class Thirteen {
    public static void main(String[] args) {
        Thread thread1 = new Thread(new MyRunnable(), "Thread 1");
        Thread thread2 = new Thread(new MyRunnable(), "Thread 2");

        System.out.println(thread1.getName() + " default priority: " + thread1.getPriority());
        System.out.println(thread2.getName() + " default priority: " + thread2.getPriority());

        thread1.setPriority(Thread.MIN_PRIORITY);
        thread2.setPriority(Thread.MAX_PRIORITY);

        System.out.println(thread1.getName() + " new priority: " + thread1.getPriority());
        System.out.println(thread2.getName() + " new priority: " + thread2.getPriority());

        thread1.start();
        thread2.start();
    }

    static class MyRunnable implements Runnable {
        public void run() {
            System.out.println(Thread.currentThread().getName() + " running");
        }
    }
}