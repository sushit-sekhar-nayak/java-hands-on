// How to convert an array to string in Java?

import java.util.*;

public class Seven {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        
        // Convert the array to a string using Arrays.toString()
        String str = Arrays.toString(numbers);
        
        System.out.println(str);
    }
}